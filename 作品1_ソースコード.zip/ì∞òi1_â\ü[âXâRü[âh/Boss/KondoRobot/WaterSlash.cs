﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Player;

public class WaterSlash : MonoBehaviour
{
    [SerializeField] private int attackPoint;

    private float time = 0;
    private Vector3 frameMoveAmount;

    private void Update()
    {
        if (time <= 0) return;

        time -= Time.deltaTime;
        transform.position += frameMoveAmount * Time.deltaTime;

        if (time <= 0)
        {
            gameObject.SetActive(false);
            Destroy(gameObject);
        }
    }

    public void MoveStart(Vector2 frameMoveAmount,float time)
    {
        this.time = time;
        this.frameMoveAmount = frameMoveAmount;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == Utility.LayerNumbers.PLAYER_LAYER)
        {
            PlayerHit playerHit = null;
            if (collision.TryGetComponent(out playerHit))
            {
                PlayerDamageData damageData = new PlayerDamageData(attackPoint,true,1f,0.1f,frameMoveAmount);

                playerHit.Damage(damageData);
                //Destroy(gameObject);
            }
        }
    }
}
