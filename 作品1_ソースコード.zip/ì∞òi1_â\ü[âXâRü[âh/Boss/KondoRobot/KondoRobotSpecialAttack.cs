﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using System;

namespace Boss
{
    public class KondoRobotSpecialAttack : MonoBehaviour
    {
        [SerializeField] private int attackNumber = 3;
        [SerializeField] private float dirayTime = 3f;
        [SerializeField] private float moveTime = 0.5f;

        [SerializeField] private BigLaser[] verticaLasers;
        [SerializeField] private BigLaser[] horizontalLasers;
        private KondoRobotCore core;
        private Animator animator;

        private int count = 0;

        // Start is called before the first frame update
        void Start()
        {
            core = GetComponent<KondoRobotCore>();
            animator = GetComponent<Animator>();
            core.spAttackInit.Subscribe(StateStart);
        }

        // Update is called once per frame
        void Update()
        {

        }

        private void StateStart(Unit unit)
        {
            gameObject.tag = "Boss";
            //AmaDebug.LogRed("ゲーム開始につきボスに変化");

            count++;
            StartCoroutine(StateAct());
        }

        private IEnumerator StateAct()
        {
            int rand = 0;
            animator.SetTrigger("Move");

            yield return new WaitForSeconds(moveTime);

            transform.position = new Vector3(0, 100);


            for (int i = 0;i < attackNumber;i++)
            {
                rand = UnityEngine.Random.Range(0,verticaLasers.Length);
                verticaLasers[rand].Activate();

                rand = UnityEngine.Random.Range(0,horizontalLasers.Length);
                horizontalLasers[rand].Activate();

                yield return new WaitForSeconds(dirayTime);
            }

            core.bossState = KondoRobotState.MOVE;
            Debug.Log("State End");
        }
    }
}