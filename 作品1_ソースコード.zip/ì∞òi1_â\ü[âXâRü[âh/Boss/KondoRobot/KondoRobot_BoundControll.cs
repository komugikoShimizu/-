﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Zenject;
using Manager;
using UniRx;
using Enemy;

namespace Boss
{
    class KondoRobot_BoundControll:MonoBehaviour
    {
        [Header("吹っ飛ばし状態を管理するクラス")]
        [SerializeField] GameObject blowEffect;
        private KondoRobotCore bossCore;
        [Inject] private IGetStartBoundMove getStartBoundMove;
        [Inject] private IGetEndBoundMove getEndBoundMove;

        private void Start()
        {
            getEndBoundMove = Locator<IGetEndBoundMove>.GetT();
            getStartBoundMove = Locator<IGetStartBoundMove>.GetT();
            bossCore = GetComponent<KondoRobotCore>();
            getStartBoundMove.GetStartBoundMove().Where(_ => _ == bossCore.id).Subscribe(StartBound);
            getEndBoundMove.GetEndBoundMove().Where(_ => _ == bossCore.id).Subscribe(EndBound);
            blowEffect.SetActive(false);
        }
        private void StartBound(int _)
        {
            //Debug.Log("バウンド開始");
            bossCore.state = EnemyState.DAMAGE;
            //bossCore.bossState = KondoRobotState.DAMAGE;
            blowEffect.SetActive(true);
        }
        private void EndBound(int _)
        {
            //Debug.Log("バウンド終了");
            bossCore.state = EnemyState.STAY;
            //bossCore.bossState = KondoRobotState.STAY;
            blowEffect.SetActive(false);
        }
    }
}
