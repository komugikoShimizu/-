﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum KondoRobotState 
{
    STAY,
    MOVE,
    CREAN,
    ATTACK,
    SP_ATTACK,
    SUMMON,
    STUN,
    DAMAGE,
    DIE
}
