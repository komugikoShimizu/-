﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
using UniRx;
using Manager;

namespace Boss
{
    public class KondoRobotMove : MonoBehaviour
    {
        [Inject] private IGetStartBoundMove startBoundMove;
        [SerializeField] private float moveDistance = 12f;
        [SerializeField] private List<Vector2> movePoint;
        [SerializeField] private GameObject bubble;
        [SerializeField] private CleanerSound sound = null;

        private KondoRobotCore core;
        private Coroutine coroutine;
        private GameObject instance;
        private GameObject instance_;
        private Animator animator;

        // Start is called before the first frame update
        void Awake()
        {
            core ??= GetComponent<KondoRobotCore>();
            core.moveInit.Subscribe(MoveStart);
            animator = GetComponent<Animator>();
            startBoundMove.GetStartBoundMove().Where(_ => _ == core.id).Subscribe(BoundStart);
        }

        // Update is called once per frame
        void Update()
        {
            if (core.bossState != KondoRobotState.MOVE) return;

        }

        private void MoveStart(Unit unit)
        {
            gameObject.tag = "Boss";
            //AmaDebug.LogRed("動き出したためボスに変化");

            if (coroutine != null) StopCoroutine(coroutine);
            coroutine = StartCoroutine(enumerator());
            //animator.SetBool("Stay_",false);
            animator.SetTrigger("Move");
            Debug.Log("アニメーションがMoveに変更");
            //animator.Play("Boss_Cleaner_MopSwing2");
        }

        private IEnumerator enumerator()
        {
            List<Vector2> targetPos = new List<Vector2>();

            if (core.movePos == Vector3.zero)
            {
                for (int i = 0; i < movePoint.Count; i++)
                {
                    if (moveDistance > core.ToPlayerDistance(movePoint[i])) continue;
                    targetPos.Add(movePoint[i]);
                }

                if (targetPos.Count <= 0) targetPos.Add(movePoint[Random.Range(0, movePoint.Count)]);
            }
            else targetPos.Add(core.movePos);
            core.movePos = Vector3.zero;

            int rand = Random.Range(0, targetPos.Count);

            // モップを振り回す音を再生開始
            sound.PlayCleanerMoveBubbleSound();

            if (instance != null) Destroy(instance);
            instance = Instantiate(bubble, transform.position, Quaternion.identity);

            if (instance_ != null) Destroy(instance_);
            instance_ = Instantiate(bubble, targetPos[rand],Quaternion.identity);

            yield return new WaitForSeconds(0.5f);

            // モップを振り回す音を止める
            sound.StopCleanerMoveBubbleSound();
            if (coroutine != null) transform.position = targetPos[rand];

        }

        private void BoundStart(int num)
        {
            if (coroutine is null) return;
            StopCoroutine(coroutine);
            coroutine = null;
        }


        public void AnimationEnd_Move()
        {
            if (GameManager.GameState != GameState.GAME) return;
            if (core.bossState != KondoRobotState.MOVE) return;
            if (coroutine != null)
            {
                StopCoroutine(coroutine);
                coroutine = null; 
            }
            gameObject.tag = "Boss";
            //AmaDebug.LogRed("移動アニメーションからボスに変化");

            Debug.Log("MoveAnimationEnd");
            core.bossState = KondoRobotState.STAY;
        }
    }
}
