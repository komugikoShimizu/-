﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Enemy;
using Manager;
using Effect;
using Zenject;
using UniRx;

namespace Boss
{
    public class KondoRobotDie : MonoBehaviour
    {
        [Inject] private IEffectCreatable effectCreatable;
        [SerializeField] private int bombCount = 7;
        [SerializeField] private Vector2 bombInstnaceDistance = new Vector2(3,3);
        [SerializeField] private CleanerSound sound = null;

        private KondoRobotCore core;

        // Start is called before the first frame update
        void Start()
        {
            core ??= GetComponent<KondoRobotCore>();
            core.dieInit.Subscribe(DieStart);
        }

        // Update is called once per frame
        void Update()
        {

        }

        private void DieStart(Unit unit)
        {
            if (!gameObject.activeSelf) return;
            StartCoroutine(Break());
        }

        private IEnumerator Break()
        {
            core.destroyAction?.Invoke(default);

            for (int i = 0;i < bombCount;i++)
            {
                float randX = Random.Range(-bombInstnaceDistance.x,bombInstnaceDistance.x);
                float randY = Random.Range(-bombInstnaceDistance.y,bombInstnaceDistance.y);
                effectCreatable.CreatEffect(core.dieEffect, transform.position + new Vector3(randX,randY));
                sound.PlayCleanerDeadSound();
                yield return new WaitForSeconds(0.5f);
            }

            gameObject.SetActive(false);
        }
    }
}