﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using UI.CleanerHP;
using Enemy;

namespace Boss
{
    /// <summary>
    /// クリナギオンのステータスを扱うクラス
    /// </summary>
    public class KondoRobotCore : BossCore
    {
        public KondoRobotState state_ = KondoRobotState.STAY;   // ボス専用ステート
        public float attackDistance = 3f;                       // 攻撃を行う距離
        public Vector3 movePos;                                 // 移動座標の生成
        public CleanerHPUI hpUI;                                // HPゲージ
        public GameObject bubble;                               // 登場時の泡生成用

        [SerializeField,Tooltip("プレイヤーのオブジェクト")] private GameObject playerObject;
        [SerializeField,Tooltip("初期座標")] private Vector3 basePos;
        [SerializeField,Tooltip("移動を行う座標")] private Vector3[] movePosArray;

        // ステート変更時のイベント
        private Subject<Unit> stayInitAct = new Subject<Unit>();
        private Subject<Unit> moveInitAct = new Subject<Unit>();
        private Subject<Unit> attackInitAct = new Subject<Unit>();
        private Subject<Unit> spAttackInitAct = new Subject<Unit>();
        private Subject<Unit> creanInitAct = new Subject<Unit>();
        private Subject<Unit> dieInitAct = new Subject<Unit>();

        // 登録用のみを公開したステート変更時イベント
        public IObservable<Unit> stayInit { get => stayInitAct; }
        public IObservable<Unit> moveInit { get => moveInitAct; }
        public IObservable<Unit> attackInit { get => attackInitAct; }
        public IObservable<Unit> spAttackInit { get => spAttackInitAct; }
        public IObservable<Unit> creanInit { get => creanInitAct; }
        public IObservable<Unit> dieInit { get => dieInitAct; }

        /// <summary>
        /// クリナギオンのステート
        /// </summary>
        public KondoRobotState bossState
        {
            get => state_;
            set
            {
                if (state_ is KondoRobotState.DIE) return;
                Debug.Log(value);
                switch (value)
                {
                    case KondoRobotState.STAY: stayInitAct?.OnNext(default);break;
                    case KondoRobotState.MOVE: moveInitAct?.OnNext(default); break;
                    case KondoRobotState.ATTACK: attackInitAct?.OnNext(default); break;
                    case KondoRobotState.SP_ATTACK: spAttackInitAct?.OnNext(default); break;
                    case KondoRobotState.CREAN: creanInitAct?.OnNext(default); break;
                    case KondoRobotState.DIE: dieInitAct?.OnNext(default); break;
                }
                state_ = value;
            }
        }

        /// <summary>
        /// プレイヤーの座標を取得する
        /// </summary>
        public Vector3 playerPos
        {
            get => playerObject.transform.position;
        }

        /// <summary>
        /// プレイヤーとの距離を返す
        /// </summary>
        /// <param name="position">比較する座標</param>
        /// <returns></returns>
        public float ToPlayerDistance(Vector2 position)
        {
            float returnNum = Mathf.Abs(Vector2.Distance(position,playerPos));
            return returnNum;
        }

        /// <summary>
        /// 移動座標を生成する
        /// </summary>
        public void MovePosCreate()
        {
            float distance = 0;
            int index = 0;
            for (int i = 0;i < movePosArray.Length;i++)
            {
                float distance_ = ToPlayerDistance(movePosArray[i]);
                if (distance < distance_)
                {
                    index = i;
                    distance = distance_;
                }
            }
            movePos = movePosArray[index];
        }

        /// <summary>
        /// 登場時演出
        /// </summary>
        public override void Entry()
        {
            transform.position = basePos;
            hpUI.DrawInitHP(baseHitPoint, baseHitPoint);
            hpUI.GetComponent<Animator>().SetFloat("AnimationSpeed",1f);
            Animator anim = GetComponent<Animator>();
            anim.SetTrigger("Move");
            anim.SetFloat("AnimationSpeed", 1f);
            Instantiate(bubble,transform.position,Quaternion.identity);
        }
    }
}