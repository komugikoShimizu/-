﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;

namespace Boss
{
    public class KondoRobotCrean : MonoBehaviour
    {
        private Animator animator;
        private KondoRobotCore core;

        // Start is called before the first frame update
        void Start()
        {
            animator ??= GetComponent<Animator>();
            core ??= GetComponent<KondoRobotCore>();
            core.creanInit.Subscribe(AnimationStart);
        }

        // Update is called once per frame
        void Update()
        {
            if (core.bossState != KondoRobotState.CREAN) return;
        }

        private void AnimationStart(Unit unit)
        {
            animator.SetTrigger("Crean");
            animator.SetInteger("AnimationNumber",0);
            gameObject.tag = "Enemy";
        }
    }
}