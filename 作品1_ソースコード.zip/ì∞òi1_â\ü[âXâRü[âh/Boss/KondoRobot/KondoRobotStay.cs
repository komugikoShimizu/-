﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;

namespace Boss
{
    public class KondoRobotStay : MonoBehaviour
    {
        [SerializeField] private float upPointY;
        [SerializeField] private float downPointY;
        [SerializeField] private int hpLimit1 = 4000;
        [SerializeField] private int hpLimit2 = 2000;

        private bool spAttackFlg1 = false;
        private bool spAttackFlg2 = false;
        private Animator animator;
        private KondoRobotCore core;

        // Start is called before the first frame update
        void Start()
        {
            animator = GetComponent<Animator>();
            core ??= GetComponent<KondoRobotCore>();
            core.stayInit.Subscribe(MoveInitialize);
        }

        // Update is called once per frame
        void Update()
        {
            if (core.bossState != KondoRobotState.STAY) return;

            if ((!spAttackFlg1 && core.hp < hpLimit1) || (!spAttackFlg2 && core.hp < hpLimit2))
            {
                if (spAttackFlg1) spAttackFlg2 = true;
                else spAttackFlg1 = true;
                core.bossState = KondoRobotState.SP_ATTACK;
                return;
            }

            float distance = core.ToPlayerDistance(transform.position);

            if (core.movePos != Vector3.zero)
            {
                Debug.Log("移動地点が設定されているためMoveへ遷移");
                core.bossState = KondoRobotState.MOVE;
                return;
            }

            if (distance < core.attackDistance)
            {
                Debug.Log("プレイヤーが付近にいるため遷移");
                core.bossState = KondoRobotState.MOVE;
            }
            else
            {
                int point = Mathf.Abs(PointCheck(core.playerPos) + PointCheck(transform.position));

                if (point >= 2) core.bossState = KondoRobotState.ATTACK;
            }
        }

        private void MoveInitialize(Unit unit)
        {
            Debug.Log("アニメーションがStayに変更");
            gameObject.tag = "Boss";
        }

        private int PointCheck(Vector2 pos)
        {
            if (upPointY < pos.y) return 1;
            else if (downPointY > pos.y) return -1;
            else return 0;
        }

        public void StayAnimationEnd()
        {
            if (core.bossState is KondoRobotState.STAY) return;

            if ((!spAttackFlg1 && core.hp < hpLimit1) || (!spAttackFlg2 && core.hp < hpLimit2))
            {
                if (spAttackFlg1) spAttackFlg2 = true;
                else spAttackFlg1 = true;
                core.bossState = KondoRobotState.SP_ATTACK;
                return;
            }

            float distance = core.ToPlayerDistance(transform.position);

            if (core.movePos != Vector3.zero)
            {
                core.bossState = KondoRobotState.MOVE;
                return;
            }

            if (distance < core.attackDistance) core.bossState = KondoRobotState.MOVE;
            else
            {
                int point = Mathf.Abs(PointCheck(core.playerPos) + PointCheck(transform.position));

                if (point >= 2) core.bossState = KondoRobotState.ATTACK;
            }
        }
    }
}