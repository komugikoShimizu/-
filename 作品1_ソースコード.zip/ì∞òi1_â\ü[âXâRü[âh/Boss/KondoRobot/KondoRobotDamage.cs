﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
using UniRx;
using Enemy;
using Enemy.Bot;
using UI.CleanerHP;
using Manager;
using Effect;

namespace Boss
{
    public class KondoRobotDamage : EnemyDamage
    {
        [Inject] private IGetStartBoundMove startBoundMove;
        [Inject] private IGetEndBoundMove endBoundMove;

        [SerializeField] private float damageTime = 5f;
        [SerializeField] private GameObject smoke;
        private int maxHp;
        private int oldHp;
        private float timeCount;
        private KondoRobotCore core;
        private Animator animator;
        [Inject] private IEffectCreatable effectCreatable;

        protected override void StartAct()
        {
            effectCreatable ??= Locator<IEffectCreatable>.GetT();
            base.StartAct();
            core ??= GetComponent<KondoRobotCore>();
            animator = GetComponent<Animator>();

            effectCreatable ??= Locator<IEffectCreatable>.GetT();
            endBoundMove ??= Locator<IGetEndBoundMove>.GetT();
            startBoundMove.GetStartBoundMove().Where(_ => _ == core.id).Subscribe(BoundStart);
            endBoundMove.GetEndBoundMove().Where(_ => _ == core.id).Subscribe(/*_ => { laserBotCore.isBound = false; }*/BoundEnd);
            getEnemyDamageData.GetEnemyDamageData().Where(_ => _.id == enemyCore.id).Subscribe(Damage);
            maxHp = core.hp;
        }

        private void Update()
        {
            // Debug.Log($"bossstate={core.bossState} state={core.state}");
            if (core.bossState != KondoRobotState.DAMAGE) return;
            timeCount += Time.deltaTime;
            if (timeCount < damageTime || gameObject.tag != "Enemy") return;
            timeCount = 0f;
            BoundEnd(default);
        }

        private void BoundStart(int num)
        {
            smoke.SetActive(true);
            gameObject.tag = "NotHitPunchEnemy";
            timeCount = 0;
            if (core.bossState != KondoRobotState.DAMAGE)
            {
                animator.SetTrigger("Stun");
                core.bossState = KondoRobotState.DAMAGE;
            }
        }

        private void BoundEnd(int num)
        {
            Debug.Log("バウンド終了");
            gameObject.tag = "Boss";

            smoke.SetActive(false);
            //core.state = EnemyState.STAY;
            //core.bossState = KondoRobotState.STAY;
            core.MovePosCreate();
            if (core.hp > 0) animator.Play("Boss_Cleaner_ReturnFromStun");
            else core.bossState = KondoRobotState.DIE;
        }

        protected override void Damage(EnemyDamageData enemyDamageData)
        {
            switch (enemyDamageData.damageType)
            {
                case EnemyDamageType.Punch:
                    //同じパンチに当たっていないか
                    if (!isPunch)
                    {
                        //ダメージ処理
                        isPunch = true;
                        enemyCore.hp -= PunchDamage(enemyDamageData);
                        //Debug.Log("パンチダメージ" + PunchDamage(enemyDamageData));
                        //ヒットストップ
                        GameManager.HitStopStart(0.3f);
                        //画面揺れ
                        screenShake.screenShake();
                        //サウンド
                        enemyCommonSound.PlayAttackHitSound();
                        //プレイヤーにダメージを与えたことを通知する
                        setAttackHitTimming.SetAttackHitTimming().OnNext(PunchDamage(enemyDamageData));
                        //エフェクトを出す
                        effectCreatable.CreatEffect(enemyCore.impactEffect, transform.position,
                            Mathf.Atan2(enemyDamageData.damageVec.y, enemyDamageData.damageVec.x) * Mathf.Rad2Deg + -90.0f);
                        HitEffectGanerate();
                        SonickEffectGanerate(enemyDamageData);
                        ElectricEffect();
                        oldNormalVec = Vector2.zero;
                    }
                    enemyDraw.FillDamagedColor();
                    break;
                case EnemyDamageType.Collision:

                    if (enemyCore.state == EnemyState.DAMAGE)
                    {
                        CollisionDamage(enemyDamageData);
                        WallHitEffectGanerate();
                        enemyCommonSound.PlayAttackHitSound();
                    }
                    enemyDraw.FillDamagedColor();
                    break;
                case EnemyDamageType.Wall:
                    if (enemyCore.state == EnemyState.DAMAGE)
                    {
                        if (oldNormalVec.normalized != enemyDamageData.damageVec.normalized)
                        {
                            WallDamage(enemyDamageData);
                            WallHitEffectGanerate();
                            enemyCommonSound.PlayEnemyCommonClashSound();
                        }
                        oldNormalVec = enemyDamageData.damageVec.normalized;
                    }
                    break;
                default:
                    break;
            }
            if (oldHp == core.hp) return;
            core.hpUI.DrawDamageHP(maxHp, core.hp);
            oldHp = core.hp;
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (core.bossState != KondoRobotState.DAMAGE && core.bossState != KondoRobotState.MOVE && core.bossState != KondoRobotState.DIE && core.bossState != KondoRobotState.SP_ATTACK)
            {
                BotCore botCore;
                if (collision.gameObject.tag is "Enemy" && collision.TryGetComponent(out botCore) && botCore.state is Enemy.EnemyState.DAMAGE)
                {
                    gameObject.tag = "Enemy";
                    core.state = EnemyState.DAMAGE;
                    core.bossState = KondoRobotState.DAMAGE;
                    Debug.Log("アニメーションがダメージに変更");
                    animator.SetTrigger("Stun");
                    timeCount = 0f;
                }
            }
            //if (collision.gameObject.layer == Utility.LayerNumbers.)
        }

        public void AnimationEnd_damage()
        {
            if (core.bossState != KondoRobotState.DAMAGE) return;
            gameObject.tag = "Boss";
            //AmaDebug.LogRed("ダメージアニメーションからボスに変化");

            Debug.Log("WakeupAnimationEnd");
            core.bossState = KondoRobotState.STAY;
        }
    }
}