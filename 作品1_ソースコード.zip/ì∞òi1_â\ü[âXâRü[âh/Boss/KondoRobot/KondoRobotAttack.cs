﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;

namespace Boss
{
    public class KondoRobotAttack : MonoBehaviour
    {
        [SerializeField] private WaterSlash waterSlash;
        [SerializeField] private float slashMoveDistance = 3;
        [SerializeField] private CleanerSound sound;

        private float direction;
        private Animator animator;
        private KondoRobotCore core;

        // Start is called before the first frame update
        void Awake()
        {
            animator ??= GetComponent<Animator>();
            core ??= GetComponent<KondoRobotCore>();
            core.attackInit.Subscribe(AttackStart);
        }

        // Update is called once per frame
        void Update()
        {
            if (core.bossState != KondoRobotState.ATTACK) return;
        }

        private void AttackStart(Unit unit)
        {
            direction = transform.position.x > core.playerPos.x ? -1f : 1f;
            transform.localScale = new Vector3(-direction,1);
            gameObject.tag = "Enemy";
            Debug.Log("アニメーションがAttackに変更");
            animator.SetTrigger("Attack");
        }

        public void Effectreate()
        {
            WaterSlash w = Instantiate(waterSlash,transform.position,Quaternion.identity);
            sound.PlayCleanerWaterSlashSound();
            w.transform.localScale = new Vector3(-direction,1,0);
            w.MoveStart(new Vector2(direction * slashMoveDistance ,0),10);
        }

        public void AnimationEnd_Attack()
        {
            if (core.bossState != KondoRobotState.ATTACK) return;
            gameObject.tag = "Boss";
            core.bossState = KondoRobotState.STAY;
        }
    }
}