﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigLaser : MonoBehaviour
{
    public void Activate()
    {
        gameObject.SetActive(true);
    }

    public void AnimationEnd()
    {
        gameObject.SetActive(false);
    }
}
