﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Enemy;

namespace Boss
{
    public class BossCore : EnemyCore
    {
        public virtual void Entry() { }
    }
}