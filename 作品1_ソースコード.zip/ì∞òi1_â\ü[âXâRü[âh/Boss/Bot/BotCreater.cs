﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Enemy.Bot;

namespace Boss
{
    public class BotCreater : MonoBehaviour,IStopAction
    {
        [SerializeField] private float reloadTime = 7f;
        [SerializeField] private float moveAmount = 1f;
        [SerializeField] private float moveMag = 0.3f;
        [SerializeField] private Direction direction = Direction.LEFT;
        
        private float time = 0f;
        private bool instanceStart = false;
        private IEnumerator coroutine;

        public bool Instance(BotCore core)
        {
            if (instanceStart) return false;
            time = 0f;
            instanceStart = true;
            coroutine = BotInstance(core);
            StartCoroutine(coroutine);
            return true;
        }

        private IEnumerator BotInstance(BotCore core)
        {
            while (GameManager.GameState != GameState.GAME && GameManager.GameState != GameState.EVENT)
            {
                yield return null;
            }

            if (GameManager.GameState is GameState.GAME)
            {
                while (true)
                {
                    time += Time.deltaTime;
                    if (time >= reloadTime) break;
                    else yield return null;
                }
            }

            core.gameObject.SetActive(true);
            core.gameObject.transform.position = transform.position;
            Vector3 frameMove = Vector2.zero;

            switch (direction)
            {
                case Direction.LEFT: frameMove = Vector2.right; break;
                case Direction.RIGHT: frameMove = Vector2.left; break;
                case Direction.UP: frameMove = Vector2.down; break;
                case Direction.DOWN: frameMove = Vector2.up; break;
            }

            while (true)
            {
                core.gameObject.transform.position += frameMove * moveMag;
                if (Mathf.Abs(Vector2.Distance(transform.position, core.transform.position)) >= moveAmount) break;
                else yield return null;
            }

            core.Initalize();
            instanceStart = false;

            yield break;
        }

        void IStopAction.StopAction()
        {
            if (instanceStart) StopCoroutine(coroutine);
        }

        void IStopAction.RestartAction()
        {
            if (instanceStart) StartCoroutine(coroutine);
        }
    }
}