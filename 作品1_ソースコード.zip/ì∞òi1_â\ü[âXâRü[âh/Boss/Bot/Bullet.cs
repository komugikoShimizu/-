﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Player;

namespace Enemy.Bot
{
    public class Bullet : MonoBehaviour
    {
        [SerializeField] private int attackPoint;
        [SerializeField] private float frameMoveAmount = 0.1f;

        private Vector3 direction = new Vector3();
        private Action destroyAction;

        private void Update()
        {
            transform.position += direction * Time.deltaTime;
        }

        public void Activate(Vector3 direction,Action act)
        {
            this.direction = direction;
            destroyAction = act;
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.gameObject.layer == Utility.LayerNumbers.NORMAL_GROUND_LAYER)
            {
                destroyAction();
                Destroy(gameObject);
            }

            if (collision.gameObject.layer == Utility.LayerNumbers.PLAYER_LAYER)
            {
                PlayerHit playerHit = null;
                if (collision.TryGetComponent(out playerHit))
                {
                    destroyAction();
                    playerHit.Damage(attackPoint);
                    Destroy(gameObject);
                }
            }
        }
    }

}