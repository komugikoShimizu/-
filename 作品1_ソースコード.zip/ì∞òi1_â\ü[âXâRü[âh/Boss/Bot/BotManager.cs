﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using Enemy.Bot;

namespace Boss
{
    public class BotManager : MonoBehaviour
    {
        [SerializeField] private List<BotCore> bots;
        [SerializeField] private List<BotCreater> botCreaters;
        [SerializeField] private float botRespornTime = 5f;

        private List<BotCore> dieBots = new List<BotCore>();
        private float time = 0;

        // Start is called before the first frame update
        void Start()
        {
            for (int i = 0;i < bots.Count;i++)
            {
                bots[i].dieAction += DeleteCheck;
                dieBots.Add(bots[i]);
            }
        }

        // Update is called once per frame
        void Update()
        {
            if (dieBots.Count > 0)
            {
                while (true)
                {
                    int rand = Random.Range(0, botCreaters.Count);
                    bool instance = botCreaters[rand].Instance(dieBots[0]);
                    if (!instance) continue;
                    dieBots.RemoveAt(0);
                    break;
                }

            }
        }

        public void DestroyBots(int num)
        {
            gameObject.SetActive(false);

            for (int i = 0; i < bots.Count;i++)
            {
                bots[i].state = Enemy.EnemyState.STAY;
                bots[i].hp = 0;
            }

            this.enabled = false;
        }

        private void DeleteCheck(GameObject target)
        {
            if (!gameObject.activeSelf) return;

            for (int i = 0;i < bots.Count;i++)
            {
                if (bots[i].gameObject.Equals(target))
                {
                    dieBots.Add(bots[i]);
                    break;
                }
            }
        }
    }
}