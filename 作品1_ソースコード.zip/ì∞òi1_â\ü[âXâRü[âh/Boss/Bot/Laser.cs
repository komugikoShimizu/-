﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Utility;
using Player;

public class Laser : MonoBehaviour
{
    [SerializeField] private int attackPoint = 3;
    [SerializeField] private bool enemyHit = false;
    private Coroutine coroutine;

    //private ParticleSystem ps;
    //private List<ParticleSystem.Particle> enter = new List<ParticleSystem.Particle>();

    //private const int REFRECT_LAYER = 14;

    private void Start()
    {
        // ps = GetComponent<ParticleSystem>();
    }

    private void OnParticleCollision(GameObject other)
    {
        if (coroutine is null && other.layer == LayerNumbers.PLAYER_LAYER)
        {
            PlayerHit hit;
            if (other.TryGetComponent(out hit))
            {
                hit.Damage(attackPoint);
                coroutine = StartCoroutine(stopHit());
            }
        }

        if (enemyHit)
        {
            Enemy.EnemyCore enemyDamage;
            if (other.layer == LayerNumbers.ENEMY_LAYER && other.TryGetComponent(out enemyDamage))
            {
                Debug.Log("ダメージをあたえた");
                enemyDamage.hp -= attackPoint;
            }
        }

        //else if (other.layer != REFRECT_LAYER)
        //{
        //    ParticleSystem.CollisionModule collision = ps.collision;
        //    collision.maxKillSpeed = 0;
        //    collision.bounce = 0;
        //}
        //else
        //{
        //    ParticleSystem.CollisionModule collision = ps.collision;
        //    collision.maxKillSpeed = 20000;
        //    collision.bounce = 1;
        //}
    }

    private IEnumerator stopHit()
    {
        yield return new WaitForSeconds(0.5f);

        coroutine = null;
        yield break;
    }

    private void OnDisable()
    {
        if (coroutine is null) return;
        StopCoroutine(coroutine);
        coroutine = null;
    }

}
