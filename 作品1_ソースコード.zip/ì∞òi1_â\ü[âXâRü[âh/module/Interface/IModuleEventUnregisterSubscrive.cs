﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using System;

namespace Module
{
    public interface IModuleEventUnregisterSubscrive 
    {
        IObservable<ModuleEvent> Subscriver();
    }
}