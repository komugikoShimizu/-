﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Module
{
    public interface IModuleEventExecution
    {
        /// <summary>
        /// モジュールのイベントを実行する関数です
        /// </summary>
        /// <param name="exeEvent"></param>
        void Execution(ModuleEvent exeEvent);
    }
}