﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Module;
using Manager;
using Zenject;
using System.Linq;

namespace Player
{
    public class ModuleContainer : MonoBehaviour
    {
        [Inject] private IModuleEventSubscrive subscrive;
        [Inject] private IModuleEventExecution moduleExe;
        [Inject] private IModuleEventUnregisterExecution moduleEventUnregister;
        /*[HideInInspector]*/ public List<ModuleStatus> possessedModule = new List<ModuleStatus>();
        private List<ModuleStatus> executedStatus;
        [SerializeField] private ModuleList moduleList;

        private void Awake()
        {
            Locator<ModuleContainer>.Bind(this);
            subscrive.Subscrive(ScalesOfBravery);
        }

        private void Start()
        {
            if (PlayerStatusManager.moduleStatuses is null) return;

            List<ModuleStatus> beforeSceneModule;
            beforeSceneModule = PlayerStatusManager.moduleStatuses;
            for (int i = 0;i < beforeSceneModule.Count;i++)
            {
                AddExe(beforeSceneModule[i]);
            }
        }

        public void AddExe(ModuleStatus status)
        {
            possessedModule.Add(status);

            if (status.ImmediateBootGet) moduleExe.Execution(status.eventGet);
            //if (status.ModuleTypeGet is ModuleType.consumption) possessedModule.Remove(status);
        }

        public void Execution(ModuleEvent moduleEvent)
        {
            List<int> removeNum = new List<int>();

            for (int i = 0;i < possessedModule.Count;i++)
            {
                if ((possessedModule[i].ModuleTypeGet != ModuleType.continuation) && possessedModule[i].eventGet == moduleEvent)
                {
                    if (moduleEvent is ModuleEvent.Revival)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            int rand = Random.Range(0, possessedModule.Count);

                            moduleEventUnregister.Execution().OnNext(possessedModule[i].eventGet);
                            removeNum.Add(rand);
                        }
                    }

                    moduleExe.Execution(moduleEvent);
                    possessedModule.RemoveAt(i);
                    i--;
                    continue;
                }
            }

            for (int i = 0;i < removeNum.Count;i++)
            {
                possessedModule.RemoveAt(removeNum[i]);
            }
        }

        public bool ModuleCheck(ModuleEvent moduleEvent)
        {
            for (int i = 0;i < possessedModule.Count;i++)
            {
                if (possessedModule[i].eventGet == moduleEvent) return true;
            }

            return false;
        }

        public void ModuleExe_Stage()
        {
            executedStatus = new List<ModuleStatus>();

            for (int i = 0;i < possessedModule.Count;i++)
            {
                if (possessedModule[i].StartingGet != ModuleStarting.Stage) continue;

                if (executedStatus.Any(item => (item == possessedModule[i])))
                {
                    executedStatus.Add(possessedModule[i]);
                    moduleExe.Execution(possessedModule[i].eventGet);
                }
            }
        }

        public void ModuleExe_Room()
        {
            executedStatus = new List<ModuleStatus>();

            for (int i = 0; i < possessedModule.Count; i++)
            {
                if ( possessedModule[i].StartingGet != ModuleStarting.Room) continue;

                if (executedStatus.Any(item => (item == possessedModule[i])))
                {
                    executedStatus.Add(possessedModule[i]);
                    moduleExe.Execution(possessedModule[i].eventGet);
                }
            }
        }

        private void ScalesOfBravery(ModuleEvent moduleEvent)
        {
            if (moduleEvent is ModuleEvent.ScalesOfBravery)
            {
                int rand = Random.Range(0,possessedModule.Count);

                possessedModule.RemoveAt(rand);

                for (int i = 0;i < 2;i++)
                {
                    rand = Random.Range(0, moduleList.statuses.Count);

                    if (ModuleCheck(moduleList.statuses[rand].eventGet))
                    {
                        i--;
                        continue;
                    }

                    possessedModule.Add(moduleList.statuses[rand]);
                }
            }
        }

        public void DataSave()
        {
            IBeforeSceneModuleSet moduleSet;
            moduleSet = Locator<IBeforeSceneModuleSet>.GetT();
            moduleSet.ModuleListSet(possessedModule);
        }
    }

}