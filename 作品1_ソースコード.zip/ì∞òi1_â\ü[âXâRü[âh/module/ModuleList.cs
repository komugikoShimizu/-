﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Module
{
    public class ModuleList : MonoBehaviour
    {
        public List<ModuleStatus> statuses;
    }
}