﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Module
{
    public enum ModuleStarting
    {
        Stage,
        Room,
        Others
    }
}