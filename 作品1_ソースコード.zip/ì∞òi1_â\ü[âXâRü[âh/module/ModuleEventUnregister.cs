﻿using System;
using System.Collections;
using System.Collections.Generic;
using UniRx;
using UnityEngine;

namespace Module
{
    public class ModuleEventUnregister : IModuleEventUnregisterExecution,IModuleEventUnregisterSubscrive
    {
        private Subject<ModuleEvent> modEve = new Subject<ModuleEvent>();

        IObserver<ModuleEvent> IModuleEventUnregisterExecution.Execution()
        {
            return modEve;
        }

        IObservable<ModuleEvent> IModuleEventUnregisterSubscrive.Subscriver()
        {
            return modEve;
        }
    }
}