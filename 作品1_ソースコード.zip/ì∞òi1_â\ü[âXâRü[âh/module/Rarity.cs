﻿public enum Rearlity 
{
    Comon,
    Rare,
    Epic
}
