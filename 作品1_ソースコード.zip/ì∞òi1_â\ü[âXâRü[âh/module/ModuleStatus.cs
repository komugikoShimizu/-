﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;

namespace Module
{
    public class ModuleStatus : MonoBehaviour
    {
        [Inject] private IModuleEventExecution eventExe;
        [Header("モジュールの名称")] [SerializeField] private string moduleName;
        [Header("モジュールの起こすイベント")] [SerializeField] private ModuleEvent moduleEvent;
        [Header("モジュールの説明文")] [SerializeField, TextArea] private string statement;
        [Header("モジュールのタイプ"), SerializeField] private ModuleType moduleType;
        [Header("モジュールの起動条件"), SerializeField] private ModuleStarting starting;
        [Header("即時起動するかどうか"), SerializeField] private bool immediateBoot = true;
        [Header("画像データ")] [SerializeField] private Sprite sprite;
        [Header("モジュールの値段")] [SerializeField] private int price = 10;
        [Header("レア度")] [SerializeField] private Rearlity rearlity;

        public ModuleEvent eventGet
        {
            get => moduleEvent;
        }

        public string nameGet
        {
            get => moduleName;
        }

        public string statementGet
        {
            get => statement;
        }

        public ModuleType ModuleTypeGet
        {
            get => moduleType;
        }

        public ModuleStarting StartingGet
        {
            get => starting;
        }

        public bool ImmediateBootGet
        {
            get => immediateBoot;
        }

        public Sprite spriteGet
        {
            get => sprite;
        }

        public int PriceGet
        {
            get => price;
        }

        public Rearlity rearlityGet
        {
            get => rearlity;
        }

        public void Execution()
        {
            eventExe.Execution(moduleEvent);
        }

    }
}