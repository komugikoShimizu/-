using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
using System;

namespace Module
{
    public class ModuleSubTest : MonoBehaviour
    {
        [Inject] private IModuleEventSubscrive subscrive;

        // Start is called before the first frame update
        void Start()
        {
            subscrive.Subscrive(SubScriver); // �C�x���g�o�^���@
        }

        private void SubScriver(ModuleEvent moduleEvent)
        {
            if (moduleEvent is ModuleEvent.debug)
            {
                Debug.Log("�e�X�g����");
            }
        }
    }
}