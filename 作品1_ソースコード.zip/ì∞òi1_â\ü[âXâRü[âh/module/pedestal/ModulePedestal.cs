﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DisplayInput;

namespace Module
{
    public class ModulePedestal : EventPoint
    {
        [SerializeField] private SpriteRenderer lightRenderer;
        [SerializeField] private SpriteRenderer moduleRenderer;

        private Coroutine coroutine;
        private DisplayInputKeyImage displayInput;

        public void Active(ModuleStatus setModule)
        {
            moduleRenderer.sprite = setModule.spriteGet;
            displayInput = GetComponent<DisplayInputKeyImage>();
        }

        public void ReAcive()
        {
            lightRenderer.color = Vector4.zero;
        }

        public void Off()
        {
            moduleRenderer.sprite = null;
            if (coroutine != null) return;
            coroutine = StartCoroutine(enumerator());
            if (onPlayer) displayInput.StopDisplayImage();
            displayInput = null;
        }

        protected override void EnterAction(Collider2D collision)
        {
            if (displayInput is null) return;
            if (collision.gameObject.layer is 3 && !onPlayer)
            {
                onPlayer_ = true;
                displayInput.DisplayImage();
            }
        }

        protected override void ExitAction(Collider2D collision)
        {
            if (displayInput is null) return;
            if (collision.gameObject.layer is 3 && onPlayer)
            {
                onPlayer_ = false;
                displayInput.StopDisplayImage();
            }
        }

        private IEnumerator enumerator()
        {
            while (true)
            {
                lightRenderer.color -= new Color(0,0,0,0.02f);
                if (lightRenderer.color.a <= 0f) break;
                yield return null;
            }
        }
    }
}