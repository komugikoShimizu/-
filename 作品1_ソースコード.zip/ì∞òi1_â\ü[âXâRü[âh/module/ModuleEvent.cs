﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Module
{
    /// モジュールの起こすイベントを増やすとき、ここの値を追加すること
    /// 自身のイベントではないときに早期リターンすること

    /// <summary>
    /// モジュールイベントを表記するenum
    /// </summary>
    public enum ModuleEvent 
    {
        debug,
        HPPlus20,
        Armor,
        Heal30,
        MapDisplay,
        AttackHeal,
        ScrapPlus,
        ScrapDouble,
        ScrapDoubling,
        RoomHeal,
        Weakening,
        FullCharge,
        PercentageDamage,
        CoinOperatedToys,
        InReturn_Scrap,
        CrisisBoost,
        RespornPlus,
        Revival,
        ScalesOfBravery,
        PlayerPunchDamageMag,
        EnemyToEnemyCollisionMag,
        EnemyHitWallDamageMag,
        EnemyFixationDamage,
        AttackPointUp10,
        AttackPointUp15,
        AttackPointUp20,
        AttackPointUp25,
        BlowPowerUp10,
        BlowPowerUp15,
        BlowPowerUp20,
        BlowPowerUp25,
        AvoidCoolTimeShortening,
        AvoidUpperLimitUp
    }
}