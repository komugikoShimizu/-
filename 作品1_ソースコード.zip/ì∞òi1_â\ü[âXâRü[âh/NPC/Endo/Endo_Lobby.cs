﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;

namespace npc
{
    /// <summary>
    /// ロビー内のエンドー博士のクラス
    /// </summary>
    public class Endo_Lobby : npcController
    {
        [SerializeField, Tooltip("トレーニングの間隔")] private float traningInterval = 30f;
        [SerializeField, Tooltip("トレーニングを行う時間")] private float traningTime = 10f;
        [SerializeField, Tooltip("倒れている時間")] private float regretTime = 5f;
        [SerializeField, Tooltip("チュートリアルの保存用クラス")] private SaveTutorialDatas saveTutorial;

        private float time = 0;
        private bool talk = false;
        private Animator animator;
        private Coroutine coroutine;
        private Subject<Unit> sub = new Subject<Unit>();

        protected override void Startup()
        {
            base.Startup();
            animator = GetComponent<Animator>();
            sub.Subscribe(TalkFlgReset);
        }

        protected override void Talk()
        {
            // トレーニング
            //if (coroutine is null && !talk && GameManager.GameState is GameState.GAME)
            //{
            //    time += Time.deltaTime;
            //    if (time >= traningInterval)
            //    {
            //        coroutine = StartCoroutine(Traning());
            //        time = 0f;
            //    }
            //}

            if (talkSummary != null && onPlayer && inputManager.InteractInput())
            {
                if (coroutine != null)
                {
                    StopCoroutine(coroutine);
                    coroutine = null;
                    animator.SetTrigger("Getup");
                }
                talk = true;
                if (GameManager.tutorialFlg) index = Random.Range(1, talkSummary.Count);
                else
                {
                    index = 0;
                    sub.Subscribe(TutorialComp);
                }
                talkStarting.TalkOpen(talkSummary[index],sub);
            }
        }

        private void TalkFlgReset(Unit unit)
        {
            talk = false;
        }

        private void TutorialComp(Unit unit)
        {
            GameManager.tutorialFlg = true;
            saveTutorial.SaveTutorialData();
        }

        private IEnumerator Traning()
        {
            animator.SetTrigger("Training");

            yield return new WaitForSeconds(traningTime);

            int rand = Random.Range(0,10);

            if (rand >= 5) animator.SetTrigger("Getup");
            else
            {
                animator.SetTrigger("Down");
                yield return new WaitForSeconds(regretTime);
                animator.SetTrigger("Getup");
            }

            coroutine = null;
        }
    }
}