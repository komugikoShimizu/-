﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Zenject;
using Manager;
using Utility;

namespace npc
{
    public class Endo_Boss : MonoBehaviour
    {
        [Inject] private ILengthCast lengthCast;

        [SerializeField] private float moveAmount = 2f;
        [SerializeField] private float radius = 0.5f;
        [SerializeField] private Vector2 basePos;

        private float flip = -1f;
        private bool walkStart = false;
        private Animator animator;
        private SpriteRenderer spriteRenderer;
        private EndoWallHitTalk EndoWallHit;

        private void OnEnable()
        {
            animator = GetComponent<Animator>();
            spriteRenderer = GetComponent<SpriteRenderer>();
            EndoWallHit = GetComponent<EndoWallHitTalk>();
        }

        private void Update()
        {
            if (!walkStart) return;
            transform.position += new Vector3(moveAmount * flip * Time.deltaTime,0,0);
            bool ray = lengthCast.CheckRay(transform.position,new Vector2(flip,0),LayerNumbers.NORMAL_GROUND_LAYER,(radius + moveAmount * Time.deltaTime));
            if (ray) Flip();
        }

        public void WalkStart()
        {
            gameObject.SetActive(true);
            transform.position = basePos;
            animator.SetTrigger("Walk");
        }

        public void WalkEnd()
        {
            animator.SetTrigger("Stay");
            spriteRenderer.flipX = true;
        }

        public void TalkEnd(Action talkAct)
        {
            gameObject.tag = "Enemy";
            walkStart = true;
            animator.SetTrigger("Run");
            EndoWallHit.talk = talkAct;
            Flip();
        }

        private void Flip()
        {
            if (spriteRenderer.flipX) spriteRenderer.flipX = false;
            else spriteRenderer.flipX = true;

            flip = spriteRenderer.flipX ? 1 : -1;
        }
    }
}