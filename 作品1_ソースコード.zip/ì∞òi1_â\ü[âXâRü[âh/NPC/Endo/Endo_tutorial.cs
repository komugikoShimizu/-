﻿using System;
using UnityEngine;
using UniRx;

namespace npc
{
    public class Endo_tutorial : npcController
    {
        public Subject<Unit> action;
        private float time;
        private bool end = false;
        private bool active = false;
        private Animator animator;

        public bool endFlg
        {
            get => end;
        }

        public void Getup()
        {
            animator.SetTrigger("Getup");
            active = true;
            if (onPlayer) displayInput.DisplayImage();
        }

        protected override void Startup()
        {
            base.Startup();
            animator = GetComponent<Animator>();
            animator.SetTrigger("Down");
        }

        protected override void EnterAction(Collider2D collsion)
        {
            if (collsion.gameObject.layer is 3 && !onPlayer)
            {
                onPlayer = true;
                if (active) displayInput.DisplayImage();
            }
        }

        protected override void ExitAction(Collider2D collision)
        {
            if (collision.gameObject.layer is 3 && onPlayer)
            {
                onPlayer = false;
                if (active) displayInput.StopDisplayImage();
            }
        }

        protected override void Talk()
        {
            if (end)
            {
                time += Time.deltaTime;
                gameObject.transform.position -= new Vector3(0.03f,0,0);
                if (time >= 5f) GameManager.GameState = GameState.GAME;
            }
            if (action is null) return;
            if (active && talkSummary != null && onPlayer && inputManager.InteractInput())
            {
                action.Subscribe(Walk);
                talkStarting.TalkOpen(talkSummary[0],action);
            }
        }

        private void Walk(Unit unit)
        {
            end = true;
            action = null;
            if (onPlayer) displayInput.StopDisplayImage();
            onPlayer = false;
            transform.localScale = new Vector3(-1,1,1);
            animator.SetTrigger("Walk");
            GameManager.GameState = GameState.TUTRIAL;
        }
    }
}