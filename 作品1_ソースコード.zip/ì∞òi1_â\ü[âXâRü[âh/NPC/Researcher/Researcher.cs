﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Manager;
using UniRx;
using Module;
using Inputs;
using UI.GiveModule;
using Research;

namespace npc
{
    public class Researcher : npcController
    {
        public Action<ModuleStatus> CompleteAct;

        private bool active = false;
        private bool giveModuleFlg = false;
        private ISendCostResearcher costResearcher;
        private Animator animator;
        private Jail jail;
        private GiveModuleModel giveModule;
        private List<ModuleStatus> modules;

        public void Activate(List<ModuleStatus> modules)
        {
            this.modules = modules;
            jail.Open(JailOpen);
        }

        protected override void Startup()
        {
            base.Startup();
            animator = GetComponent<Animator>();
            giveModule = Locator<GiveModuleModel>.GetT();
            inputManager = Locator<InputManager>.GetT();
            jail = GetComponentInChildren<Jail>();
        }

        protected override void Talk()
        {
            if (active && onPlayer && inputManager.InteractInput())
            {
                if (!giveModuleFlg)
                {
                    if (GameManager.researcherTalkFlg) GiveModuleActivate(default);
                    else
                    {
                        Subject<Unit> sub = new Subject<Unit>();
                        sub.Subscribe(GiveModuleActivate);
                        talkStarting.TalkOpen(talkSummary[0], sub);
                        GameManager.researcherTalkFlg = true;
                    }
                    Locator<IReseacherPlus>.GetT().ReseacherPlus();
                    giveModuleFlg = true;
                }
                else
                {
                    int rand = UnityEngine.Random.Range(1,talkSummary.Count);
                    talkStarting.TalkOpen(talkSummary[rand]);
                }
            }
        }

        protected override void EnterAction(Collider2D collsion)
        {
            if (collsion.gameObject.layer is 3 && !onPlayer)
            {
                onPlayer = true;
                if (active) displayInput.DisplayImage();
            }
        }

        protected override void ExitAction(Collider2D collision)
        {
            if (collision.gameObject.layer is 3 && onPlayer)
            {
                onPlayer = false;
                if (active) displayInput.StopDisplayImage();
            }
        }

        private void JailOpen()
        {
            active = true;
            animator.SetTrigger("Unlocking");
            if (onPlayer) displayInput.DisplayImage();
        }

        private void GiveModuleActivate(Unit unit)
        {
            animator.SetTrigger("Normal");
            GameManager.GameState = GameState.TALK;
            CompleteAct += Complete;
            giveModule.Activate(modules, CompleteAct);
            active = false;
        }

        private void Complete(ModuleStatus moduleStatuses)
        {
            active = true;
            if (!GameManager.researcherTalkFlg) talkStarting.TalkOpen(talkSummary[1]);
        }
    }
}
