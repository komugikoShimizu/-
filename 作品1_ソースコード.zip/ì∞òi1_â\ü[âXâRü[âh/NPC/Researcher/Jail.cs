﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace npc
{
    public class Jail : MonoBehaviour
    {
        private Animator animator;
        private Action action;

        // Start is called before the first frame update
        void Start()
        {
            animator = GetComponent<Animator>();
        }

        public void Open(Action compAct)
        {
            animator.SetTrigger("Open");
            action = compAct;
        }

        public void Destroy()
        {
            action();
            gameObject.SetActive(false);
        }
    }
}