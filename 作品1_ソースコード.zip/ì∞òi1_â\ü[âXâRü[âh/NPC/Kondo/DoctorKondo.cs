﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Boss
{
    public class DoctorKondo : MonoBehaviour
    {
        private Animator animator;

        private void Awake()
        {
            animator = GetComponent<Animator>();
        }

        public void Jump()
        {
            animator.SetTrigger("Jump");
        }

        public void Entry()
        {
            gameObject.SetActive(true);
            animator.SetTrigger("JumpDown");
        }

        public void AnimationEnd()
        {
            gameObject.SetActive(false);
        }
    }
}