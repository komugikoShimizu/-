﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
using Talk;
using Inputs;
using DisplayInput;

namespace npc
{
    public class npcController : MonoBehaviour
    {
        [Inject] protected InputManager inputManager;
        [SerializeField] protected List<TalkSummary> talkSummary;
        protected int index = 0;
        protected bool onPlayer = false;
        protected DisplayInputKeyImage displayInput;
        protected ITalkStarting talkStarting;

        // Start is called before the first frame update
        void Start()
        {
            Startup();
        }

        // Update is called once per frame
        void Update()
        {
            Talk();
        }

        protected void OnTriggerEnter2D(Collider2D collision)
        {
            EnterAction(collision);
        }

        protected void OnTriggerExit2D(Collider2D collision)
        {
            ExitAction(collision);
        }

        protected virtual void Startup()
        {
            talkStarting = Locator<ITalkStarting>.GetT();
            displayInput ??= GetComponent<DisplayInputKeyImage>();
        }

        protected virtual void Talk()
        {
            if (talkSummary != null && onPlayer && inputManager.InteractInput())
            {
                index = Random.Range(0,talkSummary.Count);
                talkStarting.TalkOpen(talkSummary[index]);
            }
        }

        protected virtual void EnterAction(Collider2D collsion)
        {
            if (collsion.gameObject.layer is 3 && !onPlayer)
            {
                onPlayer = true;
                displayInput.DisplayImage();
            }
        }

        protected virtual void ExitAction(Collider2D collision)
        {
            if (collision.gameObject.layer is 3 && onPlayer)
            {
                onPlayer = false;
                displayInput.StopDisplayImage();
            }
        }
    }
}