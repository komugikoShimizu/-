﻿using System;
using UnityEngine;
using UnityEngine.Pool;

// テスト用　部屋詳細
public class TestRoom
{
    public RoomType roomType;   // どんな部屋か
    public RoomCreateData roomData;
    public byte _direction = 0;  // 方向格納byte変数
    public bool clearFlg = false;
    public bool moduleFlg = false;

    public byte direction
    {
        get => _direction;
        set
        {
            _direction = value;
            Debug.Log($"Type is {roomType}({direction})");
        }
    }

    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="roomType">部屋情報</param>
    /// <param name="direction">方向情報</param>
    public TestRoom(RoomType roomType,byte direction = 0)
    {
        switch (roomType)
        {
            case RoomType.NONE:                     // 初期が空白部屋なら
                this.direction = 0;                 // 方向情報を0に設定
                break;
            case RoomType.NORMAL:                   // 初期が通常部屋なら
                this.direction = direction;         // 設定された方向情報に設定
                break;
            case RoomType.START:                    // 初期が開始地点なら
                this.direction = 15;                // 方向を最大値に設定
                break;
            default:
                this.direction = direction;
                break;
        }

        this.roomType = roomType;
    }

    public static LoadDirection TestNextDirection(LoadDirection baseDirection)
    {
        if (baseDirection is LoadDirection.NONE) return LoadDirection.LEFT;
        if (baseDirection is LoadDirection.LEFT) return LoadDirection.RIGHT;
        if (baseDirection is LoadDirection.RIGHT) return LoadDirection.UP;
        if (baseDirection is LoadDirection.UP) return LoadDirection.DOWN;
        return LoadDirection.MAX;
    }

    public static LoadDirection TestReverseDirection(LoadDirection baseDirection)
    {
        if (baseDirection is LoadDirection.LEFT) return LoadDirection.RIGHT;
        if (baseDirection is LoadDirection.RIGHT) return LoadDirection.LEFT;
        if (baseDirection is LoadDirection.UP) return LoadDirection.DOWN;
        if (baseDirection is LoadDirection.DOWN) return LoadDirection.UP;
        Debug.Log($"予期せぬ数値です({baseDirection})");
        return LoadDirection.MAX;
    }
}


// テスト用　部屋情報
public enum RoomType
{
    NONE = -1,
    NORMAL = 0,
    START = 1,
    JEIL = 2,
    SHOP = 3,
    SUBBOSS = 4,
    MODULE = 5,
    MAINBOSS = 6,
}

public enum LoadDirection
{
    NONE = 0,
    LEFT = 1,
    RIGHT = 2,
    UP = 4,
    DOWN = 8,
    MAX = 16
}
