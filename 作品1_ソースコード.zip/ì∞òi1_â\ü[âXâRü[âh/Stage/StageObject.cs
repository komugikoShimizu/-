﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using Zenject;
using Module;
using Player;
using Inputs;
using Manager;
using Scrap;
using UI.FadePanel;
using UI.GiveModule;
using TMPro;
using Sound;
using BoundMaster;

public class StageObject : MonoBehaviour
{
    [Inject] private InputManager inputManager;
    [Inject] private StageCreater stageCreater;
    [Inject] private IModuleEventSubscrive moduleSub;
    [Inject] private ISetAllEnemyDie setAllEnemyDie;
    [SerializeField, Tooltip("プレイヤーオブジェクト")] private GameObject playerObject;
    [SerializeField, Tooltip("エネミーオブジェクトプール")] private EnemyPool pool;
    [SerializeField, Tooltip("フェードに使用するUI")] private FadePanelUI fade;
    [SerializeField, Tooltip("モジュール説明文(そのうち消す)")] private TextMeshProUGUI statement;
    [Header("ドア用のオブジェクト設定項目")]
    [SerializeField, Tooltip("左用ドア")] private DoorController door_l;
    [SerializeField, Tooltip("右用ドア")] private DoorController door_r;
    [SerializeField, Tooltip("上用ドア")] private DoorController door_u;
    [SerializeField, Tooltip("下用ドア")] private DoorController door_d;
    [Header("ドア未生成時の壁スプライト設定項目")]
    [SerializeField, Tooltip("ドア未生成時の左用壁")] private Sprite wall_l;
    [SerializeField, Tooltip("ドア未生成時の右用壁")] private Sprite wall_r;
    [SerializeField, Tooltip("ドア未生成時の上用壁")] private Sprite wall_u;
    [SerializeField, Tooltip("ドア未生成時の下用壁")] private Sprite wall_d;
    [Header("ステージ情報設定項目")]
    [SerializeField, Tooltip("ステージの大きさ")] private Vector2Int stageLength;
    [SerializeField, Tooltip("空白部屋の数")] private int noneAmount = 3;
    [Header("部屋データ登録情報を反映する用のリスト")]
    [SerializeField, Tooltip("参照する敵番号一覧")] private EnemyList list_e;
    [SerializeField, Tooltip("参照するギミック番号一覧")] private GimmickList list_g;
    [SerializeField, Tooltip("参照する部屋一覧")] private RoomList list_r;
    [SerializeField, Tooltip("参照するモジュール一覧")] ModuleList list_m;
    [Header("タイルマップ設定項目")]
    [SerializeField, Tooltip("変更を書き込むタイルマップ")] private Tilemap mainTile;
    [SerializeField, Tooltip("装飾を反映するタイルマップ")] private Tilemap subTile;
    [Header("モジュール部屋用UI")]
    [SerializeField, Tooltip("")] private GameObject ui_main;
    [SerializeField, Tooltip("")] private TextMeshProUGUI moduleNameText;
    [SerializeField, Tooltip("")] private TextMeshProUGUI moduleStatementText;
    [Header("特殊部屋設定項目")]
    [SerializeField, Tooltip("店用部屋データ")] private RoomCreateData createData_shop;
    [SerializeField, Tooltip("開始地点用部屋データ")] private RoomCreateData createData_start;
    [SerializeField, Tooltip("ボス部屋用部屋データ")] private RoomCreateData createData_boss;
    [SerializeField, Tooltip("モジュール部屋データ")] private RoomCreateData createData_module;
    [SerializeField, Tooltip("研究員部屋データ")] private RoomCreateData createData_jeil;
    [Header("これより下は臨時表示")]
    public Action<Vector2Int> mapUpdate;                                        // 部屋を更新した際に発火するイベント
    private int[] statusesNums = new int[3];                                    // 表示するモジュール番号
    private TestRoom[,] rooms = new TestRoom[5, 5];                             // 生成した部屋リスト
    private Vector2Int playerPos;                                               // プレイヤーのステージ座標
    [SerializeField] private List<GameObject> createObjects = new List<GameObject>();            // 部屋をインスタンスした際に生成したオブジェクト情報(主に削除用)
    [SerializeField] private List<Enemy.EnemyCore> instanceEnemy = new List<Enemy.EnemyCore>();  // 部屋をインスタンスした際に生成したエネミー情報
    private DoorController doorUp;                                              // ドア上
    private DoorController doorDown;                                            // ドア下
    private DoorController doorLeft;                                            // ドア左
    private DoorController doorRight;                                           // ドア右
    private float gridDistanceX;                                                // タイルマップ上の1グリッドの座標間隔x
    private float gridDistanceY;                                                // タイルマップ上の1グリッドの座標間隔y
    private float enemyHPMag = 1;                                               // 敵体力減少モジュール反映用(エネミープールに書き換えたい)
    private bool createComp = false;                                            // 開始時処理が終了したかどうか
    private bool scrapComp = false;                                             // スクラップ回収が終わったかどうか
    private IScrapAbsorbable scrapAbsorbable;                                   // スクラップ回収用のやつ
    private Action directionCheck;                                              // 部屋から出る方向確認用関数アクション
    private ModuleContainer container;                                          // モジュールコンテナ
    private List<ModulePedestal> modulePedestals = new List<ModulePedestal>();  // モジュールの部屋においてある台座取得用
    private PlayerCore playerCore = null;                                       // プレイヤー情報
    private LaboDoorSound doorSound = null;                                     // サウンド
    public GameObject scrapManager;

    /// <summary>
    /// 生成したステージ情報を返します
    /// </summary>
    public TestRoom[,] StageData
    {
        get => rooms;
    }

    private void Awake()
    {
        // モジュールイベント登録(エネミー関連のためエネミープールに書き換えたい)
        moduleSub.Subscrive(EnemyHitPointDown);
        moduleSub.Subscrive(EnemyHitPointPlus);

        doorSound ??= GetComponent<LaboDoorSound>();
    }

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Startup()); // 開始処理実行
        fade.DrawInitFadeRatio(0f); // フェード情報初期化

        playerCore = Locator<PlayerCore>.GetT(); // プレイヤー情報取得
    }

    // Update is called once per frame
    void Update()
    {
        if (!createComp || GameManager.GameState != GameState.GAME) return; // 開始処理未実行　or ゲーム中でない　なら処理しない

        if (!rooms[playerPos.x, playerPos.y].clearFlg)                      // クリアしていないステージならエネミー確認
        {
            EnemyCheck();
            return;
        }

        if (rooms[playerPos.x, playerPos.y].roomType is RoomType.MODULE && modulePedestals != null) ModuleCheck_ModuleRoom(); // モジュール部屋ならモジュール確認
        if (!rooms[playerPos.x, playerPos.y].moduleFlg) return;             // モジュールが回収されていないなら処理しない
        // if (!scrapComp) return;                                             // スクラップ化が回収され切っていなければ処理しない
        directionCheck();                                                   // 移動検知関数実行

    }

    /// <summary>
    /// 上方向確認
    /// </summary>
    private void UpCheck()
    {
        if (doorUp.onPlayer)
        {
            playerPos += Vector2Int.down;                       // プレイヤーの座標を変更する
            fade.DrawFadeOut(AyahaShader.Skadi.FadeDir.Down);   // フェードアウト関数実行
            // フェードアウト待機
            StartCoroutine(FadeinwaitingTime(mainTile.GetCellCenterWorld((Vector3Int)rooms[playerPos.x, playerPos.y].roomData.downDoorPos) + new Vector3(0, gridDistanceY + 1), AyahaShader.Skadi.FadeDir.Down));
        }
    }

    /// <summary>
    /// 下方向確認
    /// </summary>
    private void DownCheck()
    {
        if (doorDown.onPlayer)
        {
            playerPos += Vector2Int.up;
            fade.DrawFadeOut(AyahaShader.Skadi.FadeDir.Up);
            StartCoroutine(FadeinwaitingTime(mainTile.GetCellCenterWorld((Vector3Int)rooms[playerPos.x, playerPos.y].roomData.topDoorPos) - new Vector3(0, gridDistanceY), AyahaShader.Skadi.FadeDir.Up));
        }
    }

    /// <summary>
    /// 左方向確認
    /// </summary>
    private void LeftCheck()
    {
        if (doorLeft.onPlayer)
        {
            playerPos += Vector2Int.left;
            fade.DrawFadeOut(AyahaShader.Skadi.FadeDir.Right);
            StartCoroutine(FadeinwaitingTime(mainTile.GetCellCenterWorld((Vector3Int)rooms[playerPos.x, playerPos.y].roomData.rightDoorPos) - new Vector3(gridDistanceX, 0), AyahaShader.Skadi.FadeDir.Right));
        }
    }

    /// <summary>
    /// 右方向確認
    /// </summary>
    private void RightCheck()
    {
        if (doorRight.onPlayer)
        {
            playerPos += Vector2Int.right;
            fade.DrawFadeOut(AyahaShader.Skadi.FadeDir.Left);
            StartCoroutine(FadeinwaitingTime(mainTile.GetCellCenterWorld((Vector3Int)rooms[playerPos.x, playerPos.y].roomData.leftDoorPos) + new Vector3(gridDistanceX, 0), AyahaShader.Skadi.FadeDir.Left));
        }
    }

    public void PointMove(Vector2Int pos)
    {
        if (!rooms[playerPos.x,playerPos.y].clearFlg || !rooms[playerPos.x,playerPos.y].moduleFlg) return;

        playerPos = pos;
        fade.DrawFadeOut(AyahaShader.Skadi.FadeDir.Left);
        StartCoroutine(FadeinwaitingTime(mainTile.GetCellCenterWorld((Vector3Int)rooms[playerPos.x, playerPos.y].roomData.leftDoorPos) + new Vector3(gridDistanceX, 0), AyahaShader.Skadi.FadeDir.Left));
    }

    /// <summary>
    /// 敵の生存情報を確認する関数
    /// </summary>
    /// <returns></returns>
    private bool EnemyCheck()
    {
        //AmaDebug.Log($"敵の数{instanceEnemy.Count} モジュール回収{rooms[playerPos.x, playerPos.y].moduleFlg} ");
        if (instanceEnemy.Count <= 0) // 既に生成した敵がすべていなくなっていたら
        {
            if (rooms[playerPos.x, playerPos.y].moduleFlg) // モジュールを回収しているかどうか
            {
                int getScrapAmount = scrapAbsorbable.CalcTotalScrapAmount();                                                    
                playerCore.SetScrapValue(getScrapAmount);
                if (!rooms[playerPos.x, playerPos.y].clearFlg) StartCoroutine(scrapAbsorbable.AbsorbedMove(ScrapComplete));
                //else ScrapComplete();
                //ScrapComplete();
                rooms[playerPos.x, playerPos.y].clearFlg = true;
                return true;
            }
            else return false;
        }

        for (int i = 0; i < instanceEnemy.Count; i++) // 残っている敵の数だけ回す
        {
            if (instanceEnemy[i].state is Enemy.EnemyState.DIE) // 生成した敵が倒れていたら
            {
                instanceEnemy[i].GetComponent<BoundCore2nd>()!.Reflash();   //バウンド情報初期化(?)
                instanceEnemy.RemoveAt(i);                                  // 検知エネミーから除外する
                i--;                                                        // 検知回数を減らす
                if (instanceEnemy.Count > 0) continue;                      // 検知するものがなくなったら処理を返す
                if (!rooms[playerPos.x, playerPos.y].moduleFlg) ModuleCheck_Jail(); // 監獄部屋でモジュール未獲得ならモジュール確認関数実行
                return true;
            }

            if (instanceEnemy[i].hp <= 0)
            {
                //AmaDebug.LogYellow($"死亡感知{ instanceEnemy[i].gameObject.name} " );
                if (instanceEnemy.Count - 1 >= i) setAllEnemyDie.SetAllEnemyDie();
            }
            else return false;
        }

        return false;
    }

    /// <summary>
    /// 監獄部屋の時モジュールの取得を検知する関数
    /// </summary>
    private void ModuleCheck_Jail()
    {
        statusesNums = RandomCreate();
        List<ModuleStatus> statuses = new List<ModuleStatus>();

        for (int i = 0; i < statusesNums.Length; i++)
        {
            statuses.Add(list_m.statuses[statusesNums[i]]);
        }

        npc.Researcher researcher;
        if (createObjects[0].TryGetComponent(out researcher))
        {
            researcher.CompleteAct = GetModule;
            researcher.Activate(statuses);
        }
    }

    /// <summary>
    /// モジュール部屋のモジュール取得を検知する関数
    /// </summary>
    private void ModuleCheck_ModuleRoom()
    {
        for (int i = 0; i < modulePedestals.Count; i++)
        {
            if (modulePedestals[i].onPlayer)
            {
                moduleNameText.text = list_m.statuses[statusesNums[i]].nameGet;
                moduleStatementText.text = list_m.statuses[statusesNums[i]].statementGet;

                if (inputManager.InteractInput())
                {
                    statement.text = default;
                    statement.gameObject.SetActive(false);
                    rooms[playerPos.x, playerPos.y].moduleFlg = true;
                    container.AddExe(list_m.statuses[statusesNums[i]]);
                    if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.UP) != 0) doorUp.Clear();
                    if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.DOWN) != 0) doorDown.Clear();
                    if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.LEFT) != 0) doorLeft.Clear();
                    if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.RIGHT) != 0) doorRight.Clear();

                    for (int j = 0; j < modulePedestals.Count; j++)
                    {
                        modulePedestals[j].Off();
                        ui_main.SetActive(false);
                    }

                    modulePedestals = null;

                    break;
                }

                break;
            }
        }
    }

    /// <summary>
    /// モジュール獲得時に実行する関数
    /// </summary>
    /// <param name="status"></param>
    private void GetModule(ModuleStatus status)
    {
        container.AddExe(status);
        rooms[playerPos.x, playerPos.y].moduleFlg = true;
        GameManager.GameState = GameState.GAME;
    }


    /// <summary>
    /// ランダムなモジュールを設定する関数
    /// </summary>
    /// <returns></returns>
    private int[] RandomCreate()
    {
        int[] value = new int[3];

        value[0] = UnityEngine.Random.Range(0, list_m.statuses.Count);

        while (true)
        {
            value[1] = UnityEngine.Random.Range(0, list_m.statuses.Count);
            if (value[0] != value[1]) break;
        }

        while (true)
        {
            value[2] = UnityEngine.Random.Range(0, list_m.statuses.Count);
            if (value[0] != value[2] && value[1] != value[2]) break;
        }

        return value;
    }

    /// <summary>
    /// 現在のプレイヤー座標の部屋を生成する関数
    /// </summary>
    private void RoomInstance()
    {
        RoomCreateData roadRoom = rooms[playerPos.x, playerPos.y].roomData;
        bool clearFlg = rooms[playerPos.x, playerPos.y].clearFlg;
        scrapComp = false;

        for (int i = instanceEnemy.Count - 1; i >= 0; i--)
        {
            Destroy(instanceEnemy[i].gameObject);
            instanceEnemy.RemoveAt(i);
        }

        if (doorUp != null) Destroy(doorUp.gameObject);
        if (doorDown != null) Destroy(doorDown.gameObject);
        if (doorLeft != null) Destroy(doorLeft.gameObject);
        if (doorRight != null) Destroy(doorRight.gameObject);

        for (int i = createObjects.Count - 1; i >= 0; i--)
        {
            Destroy(createObjects[i]);
            createObjects.RemoveAt(i);
        }

        for (int i = mainTile.cellBounds.xMin; i < mainTile.cellBounds.xMax; i++)
        {
            for (int j = mainTile.cellBounds.yMin; j < mainTile.cellBounds.yMax; j++)
            {
                if (mainTile.GetSprite(new Vector3Int(i, j)) != null)
                {
                    mainTile.SetTile(new Vector3Int(i, j), null);
                }
            }
        }

        for (int i = subTile.cellBounds.xMin; i < subTile.cellBounds.xMax; i++)
        {
            for (int j = subTile.cellBounds.yMin; j < subTile.cellBounds.yMax; j++)
            {
                if (subTile.GetSprite(new Vector3Int(i, j)) != null)
                {
                    subTile.SetTile(new Vector3Int(i, j), null);
                }
            }
        }

        mainTile.RefreshAllTiles();
        subTile.RefreshAllTiles();
        OutsideManager.tilemap = mainTile;
        if (!clearFlg)
        {
            if (roadRoom.roomType is RoomType.SHOP || roadRoom.roomType is RoomType.START)
            {
                clearFlg = true;
                rooms[playerPos.x, playerPos.y].clearFlg = true;
            }
            else
            {
                instanceEnemy = pool.Create(roadRoom.createEnemyID, roadRoom.createEnemyPos);
                for (int i = 0; i < instanceEnemy.Count; i++)
                {
                    float enemyHP = instanceEnemy[i].hp * enemyHPMag;
                    instanceEnemy[i].hp = (int)enemyHP;
                }
            }
        }

        createObjects = new List<GameObject>();

        for (int i = 0; i < roadRoom.directPlacements.Count; i++)
        {
            if (roadRoom.roomType is RoomType.JEIL && clearFlg) continue;
            createObjects.Add(Instantiate(roadRoom.directPlacements[i], roadRoom.objectPos[i], Quaternion.identity));
        }

        for (int i = 0;i < roadRoom.createGimmickID.Count;i++)
        {
            createObjects.Add(Instantiate(list_g.gimmickList[roadRoom.createGimmickID[i]], roadRoom.createGimmickPos[i], Quaternion.identity));
        }

        if (roadRoom.roomType is RoomType.MODULE)
        {
            if (!clearFlg)
            {
                statusesNums = RandomCreate();
                ui_main.SetActive(true);
                modulePedestals = new List<ModulePedestal>();

                for (int i = 0; i < createObjects.Count; i++)
                {
                    ModulePedestal modulePedestal = null;
                    if (createObjects[i].TryGetComponent(out modulePedestal))
                    {
                        modulePedestal.Active(list_m.statuses[statusesNums[modulePedestals.Count]]);
                        modulePedestals.Add(modulePedestal);
                    }
                }
            }
            else
            {
                for (int i = 0; i < createObjects.Count; i++)
                {
                    ModulePedestal modulePedestal = null;
                    if (createObjects[i].TryGetComponent(out modulePedestal))
                    {
                        modulePedestal.ReAcive();
                    }
                }
            }
        }

        if (rooms[playerPos.x, playerPos.y].roomType != RoomType.MODULE && rooms[playerPos.x, playerPos.y].roomType != RoomType.JEIL)
        {
            rooms[playerPos.x, playerPos.y].moduleFlg = true;
            Debug.Log(roadRoom.roomType);
        }

        for (int i = 0; i < roadRoom.tilePos.Count; i++)
        {
            Tile t = ScriptableObject.CreateInstance<Tile>();
            t.sprite = roadRoom.tileSprites[i];
            mainTile.SetTile((Vector3Int)roadRoom.tilePos[i], t);
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.UP) is 0)
        {
            Tile t = ScriptableObject.CreateInstance<Tile>();
            t.sprite = wall_u;
            mainTile.SetTile((Vector3Int)roadRoom.topDoorPos, t);
            t.sprite = wall_u;
            mainTile.SetTile((Vector3Int)roadRoom.topDoorPos + Vector3Int.right, t);
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.DOWN) is 0)
        {
            Tile t = ScriptableObject.CreateInstance<Tile>();
            t.sprite = wall_d;
            mainTile.SetTile((Vector3Int)roadRoom.downDoorPos, t);
            t.sprite = wall_d;
            mainTile.SetTile((Vector3Int)roadRoom.downDoorPos + Vector3Int.right, t);
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.LEFT) is 0)
        {
            Tile t = ScriptableObject.CreateInstance<Tile>();
            t.sprite = wall_l;
            mainTile.SetTile((Vector3Int)roadRoom.leftDoorPos, t);
            t.sprite = wall_l;
            mainTile.SetTile((Vector3Int)roadRoom.leftDoorPos + Vector3Int.down, t);
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.RIGHT) is 0)
        {
            Tile t = ScriptableObject.CreateInstance<Tile>();
            t.sprite = wall_r;
            mainTile.SetTile((Vector3Int)roadRoom.rightDoorPos, t);
            t.sprite = wall_r;
            mainTile.SetTile((Vector3Int)roadRoom.rightDoorPos + Vector3Int.down, t);
        }

        directionCheck = null;


        float distanceX = (mainTile.CellToWorld(mainTile.cellBounds.min + Vector3Int.right).x - mainTile.CellToWorld(mainTile.cellBounds.min).x);
        float distanceY = (mainTile.CellToWorld(mainTile.cellBounds.min).y - mainTile.CellToWorld(mainTile.cellBounds.min + Vector3Int.down).y) / 2;

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.UP) != 0)
        {
            Vector3 setPos = mainTile.CellToLocal((Vector3Int)roadRoom.topDoorPos) + new Vector3(distanceX, distanceY, 0);
            doorUp = (Instantiate(door_u, setPos, Quaternion.identity));
            if (rooms[playerPos.x, playerPos.y].clearFlg) doorUp.Open();
            directionCheck += UpCheck;
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.DOWN) != 0)
        {
            Vector3 setPos = mainTile.CellToLocal((Vector3Int)roadRoom.downDoorPos) + new Vector3(distanceX, distanceY, 0);
            doorDown = Instantiate(door_d, setPos, Quaternion.identity);
            if (rooms[playerPos.x, playerPos.y].clearFlg) doorDown.Open();
            directionCheck += DownCheck;
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.LEFT) != 0)
        {
            Vector3 setPos = mainTile.CellToLocal((Vector3Int)roadRoom.leftDoorPos) + new Vector3(distanceX / 2, 0, 0);
            doorLeft = (Instantiate(door_l, setPos, Quaternion.identity));
            if (rooms[playerPos.x, playerPos.y].clearFlg) doorLeft.Open();
            directionCheck += LeftCheck;
        }

        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.RIGHT) != 0)
        {
            Vector3 setPos = mainTile.CellToLocal((Vector3Int)roadRoom.rightDoorPos) + new Vector3(distanceX / 2, 0, 0);
            doorRight = (Instantiate(door_r, setPos, Quaternion.identity));
            if (rooms[playerPos.x, playerPos.y].clearFlg) doorRight.Open();
            directionCheck += RightCheck;
        }

        mainTile.RefreshAllTiles();

        for (int i = 0; i < roadRoom.subTilePos.Count; i++)
        {
            Tile t = ScriptableObject.CreateInstance<Tile>();
            t.sprite = roadRoom.subTileSprites[i];
            subTile.SetTile((Vector3Int)roadRoom.subTilePos[i], t);
        }

        if (roadRoom.roomType is RoomType.MODULE && !clearFlg)
        {
            clearFlg = true;
            rooms[playerPos.x, playerPos.y].clearFlg = true;
        }

        subTile.RefreshAllTiles();

        mapUpdate(playerPos);

        if (clearFlg) scrapComp = true;
    }

    /// <summary>
    /// 処理不可軽減用コルーチン
    /// </summary>
    /// <returns></returns>
    private IEnumerator Startup()
    {
        rooms = stageCreater.StageCreate(stageLength.x, stageLength.y, noneAmount); // 部屋生成を依頼
        scrapAbsorbable = Locator<IScrapAbsorbable>.GetT();

        yield return null;

        for (int i = 0; i < rooms.GetLength(0); i++)
        {
            for (int j = 0; j < rooms.GetLength(1); j++)
            {
                rooms[i, j].roomData = list_r.normalRoomList[UnityEngine.Random.Range(0, list_r.normalRoomList.Count)];
                if (rooms[i, j].roomType is RoomType.START)
                {
                    playerPos = new Vector2Int(i, j);
                    rooms[i, j].roomData = createData_start;
                }
                if (rooms[i, j].roomType is RoomType.SHOP) rooms[i, j].roomData = createData_shop;
                if (rooms[i, j].roomType is RoomType.MAINBOSS) rooms[i, j].roomData = createData_boss;
                if (rooms[i, j].roomType is RoomType.MODULE) rooms[i, j].roomData = createData_module;
                if (rooms[i, j].roomType is RoomType.JEIL) rooms[i, j].roomData = createData_jeil;
            }
        }

        yield return null;

        gridDistanceX = (mainTile.GetCellCenterWorld(mainTile.cellBounds.min + Vector3Int.right).x - mainTile.GetCellCenterWorld(mainTile.cellBounds.min).x);
        gridDistanceY = (mainTile.GetCellCenterWorld(mainTile.cellBounds.min + Vector3Int.up).y - mainTile.GetCellCenterWorld(mainTile.cellBounds.min).y);

        container = playerObject.GetComponent<ModuleContainer>();
        container.ModuleExe_Stage();

        yield return null;

        pool.Instance(rooms);

        yield return null;

        RoomInstance();

        createComp = true;
    }

    /// <summary>
    /// スクラップをすべて獲得した際に実行する関数
    /// </summary>
    private void ScrapComplete()
    {
        Scrap.ScrapMove[] scraps = scrapManager.GetComponentsInChildren<Scrap.ScrapMove>();
        for (int i = 0; i < scraps.Length; i++)
        {
            scraps[i].gameObject.transform.position = playerObject.transform.position;
        }

        scrapComp = true;
        doorSound.PlayLaboDoorOpenSound();
        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.UP) != 0) doorUp.Clear();
        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.DOWN) != 0) doorDown.Clear();
        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.LEFT) != 0) doorLeft.Clear();
        if ((rooms[playerPos.x, playerPos.y].direction & (byte)LoadDirection.RIGHT) != 0) doorRight.Clear();
    }

    /// <summary>
    /// エネミーの体力を減らすモジュール関数
    /// </summary>
    /// <param name="moduleEvent"></param>
    private void EnemyHitPointDown(ModuleEvent moduleEvent)
    {
        if (moduleEvent is ModuleEvent.Weakening) enemyHPMag *= 0.8f;
    }

    /// <summary>
    /// エネミーの体力を増やすモジュール関数
    /// </summary>
    /// <param name="moduleEvent"></param>
    private void EnemyHitPointPlus(ModuleEvent moduleEvent)
    {
        if (moduleEvent is ModuleEvent.InReturn_Scrap) enemyHPMag *= 1.2f;
    }

    /// <summary>
    /// フェード実行を待つ関数
    /// </summary>
    /// <param name="pos"></param>
    /// <param name="fadeDir"></param>
    /// <returns></returns>
    private IEnumerator FadeinwaitingTime(Vector2 pos, AyahaShader.Skadi.FadeDir fadeDir)
    {
        if (GameManager.GameState != GameState.MENU) GameManager.GameState = GameState.LOAD;

        while (true)
        {
            bool checkCallback = fade.CheckEndFadeOut();
            if (checkCallback) break;
            yield return null;
        }

        fade.DrawFadeIn(fadeDir);

        if (GameManager.GameState != GameState.MENU) GameManager.GameState = GameState.GAME;
        playerObject.transform.position = pos;
        RoomInstance();
    }
}
