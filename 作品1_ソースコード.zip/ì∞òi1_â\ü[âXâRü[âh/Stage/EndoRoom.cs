﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Talk;
using Utility;
using System;
using UniRx;
using npc;
using Enemy.CardBoard;
using Zenject;
using SceneTrans;

public class EndoRoom : MonoBehaviour
{
    private bool initFlg = false;
    private bool gameFlg = false;
    private ITalkStarting talkStarting;

    [SerializeField] private Image fade;

    [SerializeField] private EventPoint talkPoint1 = null;
    [SerializeField] private EventPoint talkPoint2 = null;

    [SerializeField] private TutorialSceneSound soundPlay;

    [SerializeField] private TalkSummary startTalk;
    [SerializeField] private TalkSummary talkSummary1;
    [SerializeField] private TalkSummary talkSummary2;

    [SerializeField] private Player.PlayerCore player;
    [SerializeField] private Endo_tutorial endo;
    [SerializeField] private GameObject door;
    [SerializeField] private List<cardBoardCore> dabs;

    [Inject] ISceneTrasnable sceneTrasnable = null;
    [SerializeField] SceneInitDataSObj lobbySceneSObj = null;

    private bool getupCheck = false;
    private DoorController doorController;
    private EventPoint sceneMovePoint;

    // Start is called before the first frame update
    void Start()
    {
        if (GameManager.GameProgress is GameProgress.TUTORIAL)
        {
            doorController ??= door.GetComponent<DoorController>();
            sceneMovePoint ??= door.GetComponent<EventPoint>();
            talkStarting = Locator<ITalkStarting>.GetT();
            Subject<Unit> sub = new Subject<Unit>();
            sub.Subscribe(DoorOpen);
            endo.action = sub;

            // if (startTalk != null) talkStarting.TalkOpen(startTalk);
            StartCoroutine(StartStory());
        }
        else
        {

        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!gameFlg) return;

        if (GameManager.GameProgress is GameProgress.TUTORIAL)
        {
            if (talkPoint1 != null && talkPoint1.onPlayer)
            {
                talkStarting.TalkOpen(talkSummary1);
                talkPoint1 = null;
            }

            if (!getupCheck)
            {
                if (dabs.Count > 0)
                {
                    for (int i = 0; i < dabs.Count; i++)
                    {
                        if (dabs[i].state is Enemy.EnemyState.DIE)
                        {
                            dabs.RemoveAt(i);
                            i--;
                            continue;
                        }
                    }
                }
                else
                {
                    endo.Getup();
                    getupCheck = true;
                }
            }
            if (sceneMovePoint != null && sceneMovePoint.onPlayer && endo.endFlg)
            {
                sceneTrasnable.NextScene(lobbySceneSObj);
                sceneMovePoint = null;
            }
        }
    }

    private void DoorOpen(Unit unit)
    {
        doorController.Open();
    }

    private void StartTalkEnd(Unit unit)
    {
        gameFlg = true;
        GameManager.GameState = GameState.GAME;
    }

    private IEnumerator StartStory()
    {
        GameManager.GameState = GameState.TUTRIAL;
        soundPlay.PlayCatastropheSound();

        yield return new WaitForSeconds(2f);

        Animator anim = player.gameObject.GetComponent<Animator>();
        anim.SetBool("Run",true);

        while (true)
        {
            player.transform.position += new Vector3(0.04f,0);
            fade.color -= new Color(0,0,0,0.02f);
            if (fade.color.a <= 0) break;
            yield return null;
        }

        anim.SetBool("Run",false);

        yield return new WaitForSeconds(0.5f);

        Subject<Unit> sub = new Subject<Unit>();
        sub.Subscribe(StartTalkEnd);

        talkStarting.TalkOpen(startTalk,sub);
    }
}
