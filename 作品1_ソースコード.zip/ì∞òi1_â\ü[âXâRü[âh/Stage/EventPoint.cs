﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventPoint : MonoBehaviour
{
    protected bool onPlayer_ = false;

    public bool onPlayer
    {
        get => onPlayer_;
    }

    protected virtual void EnterAction(Collider2D collision)
    {
        if (collision.gameObject.layer is 3) onPlayer_ = true;
    }

    protected virtual void ExitAction(Collider2D collision)
    {
        if (collision.gameObject.layer is 3) onPlayer_ = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        EnterAction(collision);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        ExitAction(collision);
    }
}
