﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Player;
using Inputs;
using DisplayInput;
using SceneTrans;
using Zenject;

public class GoalDoor : EventPoint
{
    [Inject] private ISceneTrasnable sceneTrasnable = null;
    [SerializeField] private SceneInitDataSObj sObj;
    private InputManager input;
    private PlayerCore player;
    private ModuleContainer container;
    private DisplayInputKeyImage displayInput;

    private void Start()
    {
        sceneTrasnable = Locator<SceneTransition>.GetT();
        input = Locator<InputManager>.GetT();
        player = Locator<PlayerCore>.GetT();
        container = Locator<ModuleContainer>.GetT();

        displayInput = GetComponent<DisplayInputKeyImage>();
    }

    private void Update()
    {
        if (onPlayer && input.InteractInput())
        {
            Locator<IStageClear>.GetT().GameEndClear();
            sceneTrasnable.NextScene(sObj, "CleanerBGM", "CleanerBGM", false);
        }
    }

    protected override void EnterAction(Collider2D collision)
    {
        if (collision.gameObject.layer is 3 && !onPlayer)
        {
            onPlayer_ = true;
            displayInput.DisplayImage();
        }
    }

    protected override void ExitAction(Collider2D collision)
    {
        if (collision.gameObject.layer is 3 && onPlayer)
        {
            onPlayer_ = false;
            displayInput.StopDisplayImage();
        }
    }
}
