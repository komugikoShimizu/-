﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace UI
{
    public class StageDraw : MonoBehaviour
    {
        [SerializeField] private StageObject stage;
        [SerializeField] private Image createPanelRoom;
        [SerializeField] private Image createPnaelload;
        [SerializeField] private GameObject createCanvas;
        [SerializeField] private Vector2 baseCreatePos;
        [SerializeField] private float mag = 300;
        [SerializeField] private Image start;
        [SerializeField] private Image gage;
        [SerializeField] private Image sub;
        [SerializeField] private Image main;
        [SerializeField] private Image shop;
        [SerializeField] private Image module;
        [SerializeField] private Image player;
        [SerializeField] private Image curcor;
        [SerializeField] private Image room_b;
        [SerializeField] private Image gage_b;
        [SerializeField] private Image sub_b;
        [SerializeField] private Image main_b;
        [SerializeField] private Image shop_b;
        [SerializeField] private Image module_b;

        private Vector2Int curcolPos;

        private TestRoom[,] stageData;
        private bool[,] passageArrays;

        private Image playerIcon;
        private Image[,] roomPanel;
        private Image[,] underPanels;
        private Image[,] sidePanels;

        private void Start()
        {
            stageData = stage.StageData;
            stage.mapUpdate += Drawing;
            passageArrays = new bool[stageData.GetLength(0), stageData.GetLength(1)];
            for (int i = 0; i < passageArrays.GetLength(0); i++)
            {
                for (int j = 0; j < passageArrays.GetLength(1); j++)
                {
                    passageArrays[i, j] = false;
                }
            }
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                if (curcolPos.x > 0 && passageArrays[curcolPos.x - 1, curcolPos.y])
                {
                    curcolPos = new Vector2Int(curcolPos.x - 1, curcolPos.y);
                    curcor.transform.localPosition = new Vector2(curcolPos.x * mag, -curcolPos.y * mag) + baseCreatePos;
                }
            }

            if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                if (curcolPos.x + 1 < stageData.GetLength(0) && passageArrays[curcolPos.x + 1, curcolPos.y])
                {
                    curcolPos = new Vector2Int(curcolPos.x + 1, curcolPos.y);
                    curcor.transform.localPosition = new Vector2(curcolPos.x * mag, -curcolPos.y * mag) + baseCreatePos;
                }
            }

            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                if (curcolPos.y > 0 && passageArrays[curcolPos.x, curcolPos.y - 1])
                {
                    curcolPos = new Vector2Int(curcolPos.x,curcolPos.y - 1);
                    curcor.transform.localPosition = new Vector2(curcolPos.x * mag, -curcolPos.y * mag) + baseCreatePos;
                }
            }

            if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                if (curcolPos.y + 1 < stageData.GetLength(1) && passageArrays[curcolPos.x, curcolPos.y + 1])
                {
                    curcolPos = new Vector2Int(curcolPos.x, curcolPos.y + 1);
                    curcor.transform.localPosition = new Vector2(curcolPos.x * mag, -curcolPos.y * mag) + baseCreatePos;
                }
            }
        }

        private void Drawing(Vector2Int playerPos)
        {
            passageArrays[playerPos.x, playerPos.y] = true;
            stageData = stage.StageData;
            if (underPanels is null) underPanels = new Image[stageData.GetLength(0), stageData.GetLength(1) - 1];

            if (sidePanels is null) sidePanels = new Image[stageData.GetLength(0) - 1, stageData.GetLength(1)];

            if (roomPanel is null) roomPanel = new Image[stageData.GetLength(0), stageData.GetLength(1)];

            for (int i = 0; i < stageData.GetLength(0); i++)
            {
                for (int j = 0; j < stageData.GetLength(1); j++)
                {
                    if (!passageArrays[i,j] || stageData[i,j] is null) continue;
                    Debug.Log($"LoadInstance[{i},{j}].direction = {stageData[i,j].direction}");
                    if (i > 0 && (stageData[i,j].direction & (byte)LoadDirection.LEFT) != 0 && sidePanels[i - 1,j] is null)
                    {
                        float num = i is 0 ? 0.5f : i - 0.5f;
                        sidePanels[i - 1, j] = Instantiate(createPnaelload,/* new Vector3(i + 0.5f, j + 0.5f), Quaternion.identity,*/ createCanvas.transform);
                        sidePanels[i - 1, j].transform.localPosition = new Vector2(num * mag, -j * mag) + baseCreatePos;
                        sidePanels[i - 1, j].SetNativeSize();
                        if (!passageArrays[i - 1, j] && roomPanel[i - 1, j] is null) roomPanel[i - 1, j] = Create_b(i - 1,j);
                    }
                    if (i < stageData.GetLength(0) - 1 && (stageData[i,j].direction & (byte)LoadDirection.RIGHT) != 0 && sidePanels[i,j] is null)
                    {

                        sidePanels[i, j] = Instantiate(createPnaelload,/* new Vector3(i + 0.5f, j + 0.5f), Quaternion.identity,*/ createCanvas.transform);
                        sidePanels[i, j].transform.localPosition = new Vector2((i + 0.5f) * mag, -j * mag) + baseCreatePos;
                        sidePanels[i, j].SetNativeSize();
                        if (!passageArrays[i + 1, j] && roomPanel[i + 1, j] is null) roomPanel[i + 1, j] = Create_b(i + 1,j);
                    }
                    if (j > 0 && (stageData[i,j].direction & (byte)LoadDirection.UP) != 0 && underPanels[i,j - 1] is null)
                    {
                        float num = j is 0 ? -0.5f : -j + 0.5f;
                        underPanels[i, j - 1] = Instantiate(createPnaelload,/* new Vector3(i + 0.5f, j + 0.5f), Quaternion.identity, */createCanvas.transform);
                        underPanels[i, j - 1].transform.localPosition = new Vector2(i * mag, num * mag) + baseCreatePos;
                        underPanels[i, j - 1].transform.eulerAngles = new Vector3(0,0,90);
                        underPanels[i, j - 1].SetNativeSize();
                        if (!passageArrays[i, j - 1] && roomPanel[i, j - 1] is null) roomPanel[i, j - 1] = Create_b(i,j - 1);
                    }
                    if (j < stageData.GetLength(1) - 1 && (stageData[i,j].direction & (byte)LoadDirection.DOWN) != 0 && underPanels[i,j] is null)
                    {
                        underPanels[i, j] = Instantiate(createPnaelload,/* new Vector3(i + 0.5f, j + 0.5f), Quaternion.identity, */createCanvas.transform);
                        underPanels[i, j].transform.localPosition = new Vector2(i * mag, (-j - 0.5f) * mag) + baseCreatePos;
                        underPanels[i, j].transform.eulerAngles = new Vector3(0, 0, 90);
                        underPanels[i, j].SetNativeSize();
                        if (!passageArrays[i, j + 1] && roomPanel[i, j + 1] is null) roomPanel[i, j + 1] = Create_b(i,j + 1);
                    }

                    Create(i,j,ref roomPanel[i,j]);
                }
            }

            // roomPanel[playerPos.x, playerPos.y].color = Color.red;

            if (playerIcon is null) playerIcon = Instantiate(player,createCanvas.transform);
            playerIcon.transform.localPosition = roomPanel[playerPos.x, playerPos.y].transform.localPosition;
            playerIcon.SetNativeSize();
            playerIcon.rectTransform.SetAsLastSibling();

            curcor.transform.localPosition = roomPanel[playerPos.x, playerPos.y].transform.localPosition;
            curcolPos = playerPos;
        }

        private void Create(int x,int y,ref Image setPanel)
        {
            Image instance = null;

            switch (stageData[x,y].roomType)
            {
                case RoomType.JEIL: instance = gage; break;
                case RoomType.MAINBOSS: instance = main; break;
                case RoomType.SHOP: instance = shop; break;
                case RoomType.START: instance = start; break;
                case RoomType.SUBBOSS: instance = sub; break;
                case RoomType.NORMAL: instance = createPanelRoom; break;
                case RoomType.MODULE: instance = module; break;
            }

            if (roomPanel[x, y])
            {
                if (roomPanel[x, y].sprite != instance) Destroy(roomPanel[x, y]);
                else return;
            }

            instance = Instantiate(instance, createCanvas.transform);
            instance.transform.localPosition = new Vector2(x * mag, -y * mag) + baseCreatePos;
            instance.SetNativeSize();
            setPanel = instance;
        }

        private Image Create_b(int x,int y)
        {
            Image instance = null;

            switch (stageData[x,y].roomType)
            {
                case RoomType.JEIL: instance = Instantiate(gage_b, createCanvas.transform); break;
                case RoomType.MAINBOSS: instance = Instantiate(main_b, createCanvas.transform); break;
                case RoomType.SHOP: instance = Instantiate(shop_b, createCanvas.transform); break;
                case RoomType.SUBBOSS: instance = Instantiate(sub_b, createCanvas.transform); break;
                case RoomType.NORMAL: instance = Instantiate(room_b, createCanvas.transform); break;
                case RoomType.MODULE: instance = Instantiate(module_b,createCanvas.transform); break;
            }

            instance.transform.localPosition = new Vector2(x * mag, -y * mag) + baseCreatePos;
            instance.SetNativeSize();

            return instance;
        }
    }

}