﻿namespace Boss
{
    /// <summary>
    /// ボスステージにおけるステージ進行状況
    /// </summary>
    public enum BossStageState
    {
        TALK_START,
        ENTRY,
        BOSS_BATTLE,
        STANDBY,
        END_TALK,
        ENDO_BOUND,
        GAME_END
    }
}