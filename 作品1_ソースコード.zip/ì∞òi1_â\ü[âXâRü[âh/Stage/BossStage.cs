﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using Zenject;
using Talk;
using npc;
using Manager;
using UI.CircleFade;
using SceneTrans;
using Sound;

namespace Boss
{
    public class BossStage : MonoBehaviour
    {
        [Inject] private IGetStartBoundMove startBoundMove;
        [Inject] private ISceneTrasnable sceneTrasnable = null;
        

        [SerializeField] private BossCore boss;
        [SerializeField] private Endo_Boss endo;
        [SerializeField] private DoctorKondo kondo;
        [SerializeField] private BotManager botManager;
        [SerializeField] private TalkSummary startTalk;
        [SerializeField] private TalkSummary endTalk;
        [SerializeField] private TalkSummary endoTalk;
        [SerializeField] private float endoId;
        [SerializeField] private CircleFadeUI circleFade;
        [SerializeField] private SceneInitDataSObj sObj;
        [SerializeField] private BossStageSound sound = null;

        [SerializeField] private Canvas zentame;
        private bool endTalkComplete = false;
        private BossStageState state;
        private ITalkStarting talkStarting;

        // Start is called before the first frame update
        void Start()
        {
            boss.destroyAction = botManager.DestroyBots;
            talkStarting = Locator<ITalkStarting>.GetT();
            Subject<Unit> sub = new Subject<Unit>();
            sub.Subscribe(StartTalkEnd);
            talkStarting.TalkOpen(startTalk,sub);
            state = BossStageState.ENTRY;
            circleFade.DrawInit(0f, default);
        }

        // Update is called once per frame
        void Update()
        {
            switch (state)
            {
                case BossStageState.TALK_START: break;
                case BossStageState.ENTRY: break;
                case BossStageState.BOSS_BATTLE:
                    if (!boss.gameObject.activeSelf) StartCoroutine(BattleEnd());
                    break;
                case BossStageState.STANDBY: break;
                case BossStageState.END_TALK: break;
                case BossStageState.ENDO_BOUND: break;
            }

        }

        private void Bound()
        {
            Subject<Unit> sub = new Subject<Unit>();
            sub.Subscribe(EndoTalkEnd);
            talkStarting.TalkOpen(endoTalk,sub);
        }

        private void EndoTalkEnd(Unit unit)
        {
            circleFade.DrawFadeout(endo.gameObject.transform.position,FadeIn);
            GameManager.GameState = GameState.EVENT;
        }

        private void StartTalkEnd(Unit unit)
        {
            sound.PlayBGMSound();
            StartCoroutine(Entry());
        }

        private IEnumerator BattleEnd()
        {
            state = BossStageState.STANDBY;
            kondo.Entry();
            endo.WalkStart();

            float count = 0;

            while (true)
            {
                count += Time.deltaTime;
                endo.transform.position = new Vector3(Mathf.Max(-count,-2f),endo.transform.position.y);
                if (count >= 2f) break;
                else yield return null;
            }

            endo.WalkEnd();

            yield return new WaitForSeconds(0.5f);

            Subject<Unit> sub = new Subject<Unit>();
            sub.Subscribe(TalkEnd);
            talkStarting.TalkOpen(endTalk,sub);
            state = BossStageState.END_TALK;
        }

        private void TalkEnd(Unit unit)
        {
            endo.TalkEnd(Bound);
            state = BossStageState.ENDO_BOUND;
        }

        private void gameEnd()
        {
            //sceneTrasnable.NextScene(sObj);
            //GameManager.GameState = GameState.GAME;

        }

        private void FadeIn()
        {
            zentame.gameObject.SetActive(true);
            sound.BGMSuppress();
        }

        private IEnumerator Entry()
        {
            GameManager.GameState = GameState.EVENT;
            kondo.Jump();
            boss.Entry();
            yield return new WaitForSeconds(3f);
            state = BossStageState.BOSS_BATTLE;
            GameManager.GameState = GameState.GAME;
        }
    }
}