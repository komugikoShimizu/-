﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ステージ作成クラス
/// </summary>
public class StageCreater
{
    private TestRoom[,] rooms = new TestRoom[5, 5]; // 保存用
    private int startX;                             // 開始地点x座標保存用
    private int startY;                             // 開始地点y座標保存用

    const int BOSSROOM_AMOUNT = 1;
    const int SUB_BOSSROOM_AMOUNT = 1;
    const int SHOPROOM_AMOUNT = 1;
    const int BOSS_START_DISTANCE = 3;

    const string ROOMDATA_CONTAINER = "/RoomDatas/";

    public TestRoom[,] StageCreate(int stageLengthX,int stageLengthY,int noneAmount)
    {
        rooms = new TestRoom[stageLengthX, stageLengthY];   // 部屋配列生成

        NoneCreate(noneAmount);                             // 空白部屋を生成

        StartCreate();                                      // 開始地点生成

        NierStartPointCreate();                             // 開始地点付近生成

        RemainingCreate();                                  // 未生成部分生成

        SpecialRoomCreate();                                // 特殊な部屋生成

        return rooms;                                       // 生成した部屋情報を送信
    }

    // 空白部屋生成関数
    private void NoneCreate(int noneAmount)
    {
        int noneCreate = noneAmount;                                    // 残生成数を設定

        while (noneCreate > 0)                                          // 残生成数がなくなるまで
        {
            int randomX = Random.Range(0, rooms.GetLength(0));          // x座標用の乱数値を生成する
            int randomY = Random.Range(0, rooms.GetLength(1));          // y座標用の乱数値を生成する

            bool flg = NierNoneRoomCheck(randomX, randomY);             // 付近に何もないかを関数を通して確認する
            if (flg)                                                    // 何もなければ
            {
                Debug.Log($"none.Create is {randomX},{randomY}");       
                rooms[randomX, randomY] = new TestRoom(RoomType.NONE);  // 生成した座標に空白部屋を生成
                noneCreate--;                                           // 残生成数を減らす
            }
        }
    }

    // 対象座標周囲8マスに何もないかを確認する
    private bool NierNoneRoomCheck(int indexX, int indexY)
    {
        int x, y;                                                                   // 確認座標保存用ローカル変数
        for (int i = -1; i <= 1; i++)                                               // x座標に加える変化量
        {
            for (int j = -1; j <= 1; j++)                                           // y座標に加える変化量
            {
                x = indexX + i;                                                     // 変化量を加味したx座標
                y = indexY + j;                                                     // 変化量を加味したy座標
                Debug.Log($"{x},{y}");
                bool xOutLangth = x >= 0 && x < rooms.GetLength(0);                 // 生成したx値が配列の境界内であるか
                bool yOutLength = y >= 0 && y < rooms.GetLength(1);                 // 生成したy値が配列の境界内であるか
                if (xOutLangth && yOutLength && rooms[x, y] != null) return false;  // 境界内の生成した座標に既に何かある場合falseを返す
            }
        }

        return true;                                                                // 全処理を正常に終えた場合trueを返す
    }

    /// <summary>
    /// 開始地点生成関数
    /// </summary>
    private void StartCreate()
    {
        while (true)
        {
            startX = Random.Range(1, rooms.GetLength(0) - 1);           // 外周を除いた乱数値xを生成する
            startY = Random.Range(1, rooms.GetLength(1) - 1);           // 外周を除いた乱数値yを生成する

            // 周辺4マスに何かがある場合乱数値を再生成する
            if (rooms[startX - 1, startY] != null) continue;        
            else if (rooms[startX + 1, startY] != null) continue;
            else if (rooms[startX, startY - 1] != null) continue;
            else if (rooms[startX, startY + 1] != null) continue;

            if (rooms[startX, startY] is null)                          // 生成座標に何もなければ
            {
                rooms[startX, startY] = new TestRoom(RoomType.START);   // 生成座標に開始地点を生成する
                break;                                                  // ループ終了
            }
        }
    }

    /// <summary>
    /// 開始地点付近を生成する
    /// </summary>
    private void NierStartPointCreate()
    {
        LoadDirection dir = 0;                                                      // 方向保存用ローカル変数
        for (int i = 0; i < 4; i++)                                                 // 計4方向分ループを回す
        {
            dir = TestRoom.TestNextDirection(dir);                                  // 次の方向を生成する

            Vector2Int offset = Vector2Int.zero;                                    // 座標差分保存用変数
            
            // 方向に応じて座標差分値を生成する
            switch (dir)                                                        
            {
                case LoadDirection.LEFT: offset = Vector2Int.left; break;
                case LoadDirection.RIGHT: offset = Vector2Int.right; break;
                case LoadDirection.UP: offset = Vector2Int.down; break;
                case LoadDirection.DOWN: offset = Vector2Int.up; break;
            }

            int createX = startX + offset.x;                                        // 差分値を加味したx座標値
            int createY = startY + offset.y;                                        // 差分値を加味したy座標値

            Debug.Log(new Vector2Int(createX, createY));
            if (rooms[createX, createY] is null) RoomCreate(createX, createY, dir); // 指定座標に部屋を生成する
            else if ((rooms[createX, createY].direction & (byte)TestRoom.TestReverseDirection(dir)) is 0) rooms[createX, createY].direction += (byte)TestRoom.TestReverseDirection(dir);    // 既に生成されていて生成先とつながっていないならつなげる
        }

        // Debug.Log("NoramlCreate End");

    }

    /// <summary>
    /// 埋まっていない部屋を生成する関数
    /// </summary>
    private void RemainingCreate()
    {
        while (true)
        {
            bool retry = false; // 継続するか                                                                                                                                               

            for (int i = 0; i < rooms.GetLength(0); i++)     // 確認用x座標
            {
                for (int j = 0; j < rooms.GetLength(1); j++) // 確認用y座標 
                {
                    if (rooms[i, j] is null)                 // 確認した座標に何もなければ
                    {
                        LoadDirection direction = LoadDirection.NONE;                                                                                                                           // 方向保存用変数
                        // 確認先が配列の境界内かつそこに既に生成した部屋があるなら確認した座標と逆の方向を保存変数に代入する
                        if (i - 1 >= 0 && rooms[i - 1, j] != null && rooms[i - 1, j].roomType != RoomType.NONE) direction = LoadDirection.RIGHT;                                                
                        else if (i + 1 < rooms.GetLength(0) && rooms[i + 1, j] != null && rooms[i + 1, j].roomType != RoomType.NONE) direction = LoadDirection.LEFT;
                        else if (j - 1 >= 0 && rooms[i, j - 1] != null && rooms[i, j - 1].roomType != RoomType.NONE) direction = LoadDirection.DOWN;
                        else if (j + 1 < rooms.GetLength(1) && rooms[i, j + 1] != null && rooms[i, j + 1].roomType != RoomType.NONE) direction = LoadDirection.UP;

                        if (direction != LoadDirection.NONE)                                                                                                                                    // 方向保存用変数が初期値から変わっていれば
                        {
                            Debug.Log($"re:Create : [{i},{j}] ({direction})");
                            RoomCreate(i, j, direction);                                                                                                                                        // 対象座標と方向に部屋生成関数を呼ぶ

                            // 方向を加味した座標にその方向情報がなければ追加する
                            if (direction is LoadDirection.RIGHT && (rooms[i - 1, j].direction & (byte)LoadDirection.RIGHT) is 0) rooms[i - 1, j].direction += (byte)LoadDirection.RIGHT;       
                            else if (direction is LoadDirection.LEFT && (rooms[i + 1, j].direction & (byte)LoadDirection.LEFT) is 0) rooms[i + 1, j].direction += (byte)LoadDirection.LEFT;
                            else if (direction is LoadDirection.DOWN && (rooms[i, j - 1].direction & (byte)LoadDirection.DOWN) is 0) rooms[i, j - 1].direction += (byte)LoadDirection.DOWN;
                            else if (direction is LoadDirection.UP && (rooms[i, j + 1].direction & (byte)LoadDirection.UP) is 0) rooms[i, j + 1].direction += (byte)LoadDirection.UP;
                            retry = true;                                                                                                                                                       // 継続する(生成漏れを防ぐため)

                        }
                    }
                }
            }

            if (!retry) break;  // 一回でも継続処理がされていれば再度ループする
        }

    }

    /// <summary>
    /// 指定された方向に何があるかを確認し、内部処理を実行する関数
    /// </summary>
    /// <param name="indexX">元座標x</param>
    /// <param name="indexY">元座標y</param>
    /// <param name="direction">確認したい方向</param>
    /// <returns></returns>
    public void DirectionCheck(int indexX, int indexY, LoadDirection direction)
    {
        int num = 0;
        bool isBoundary = false;                                            // 境界内であるかどうか
        Vector2Int pos = Vector2Int.zero;                                   // 方向を加味した座標 
        LoadDirection reverse = TestRoom.TestReverseDirection(direction);   // 確認方向と逆の方向

        switch (direction)
        {
            case LoadDirection.LEFT:
                num = indexX - 1;                   // 方向を加味した確認座標
                isBoundary = num >= 0;              // 境界内に収まっているかどうか
                pos = new Vector2Int(num, indexY);  // 確認座標作成
                break;
            case LoadDirection.RIGHT:
                num = indexX + 1;
                isBoundary = num < rooms.GetLength(0);
                pos = new Vector2Int(num, indexY);
                break;
            case LoadDirection.UP:
                num = indexY - 1;
                isBoundary = num >= 0;
                pos = new Vector2Int(indexX, num);
                break;
            case LoadDirection.DOWN:
                num = indexY + 1;
                isBoundary = num < rooms.GetLength(1);
                pos = new Vector2Int(indexX, num);
                break;
        }

        if (isBoundary)                                                                     // 境界内であれば
        {
            if (rooms[pos.x, pos.y] is null)                                                // 確認座標に何もなければ
            {
                // Debug.Log("CREATE");
                RoomCreate(pos.x, pos.y, direction);                                        // 部屋生成関数を実行
            }
            else if (rooms[pos.x, pos.y].roomType is RoomType.NONE)                         // 確認座標が空白部屋であれば
            {
                rooms[indexX, indexY].direction -= (byte)direction;                         // 元座標の部屋から方向を減算する
                // Debug.Log($"NONE ({rooms[indexX, indexY].direction})({indexX},{indexY})");
            }
            else if ((rooms[pos.x, pos.y].direction & (byte)reverse) is 0)                  // 確認座標と繋がっていなければ
            {
                // Debug.Log("CONNECT");
                rooms[pos.x, pos.y].direction += (byte)reverse;                             // 確認座標の部屋に逆方向を加算する
            }
            else
            {
                // Debug.Log($"ROOM({rooms[pos.x, pos.y].roomType},{rooms[pos.x, pos.y].direction})");
            }
        }
        else // 境界外なら
        {
            // Debug.Log($"WALL ({rooms[indexX, indexY].direction})({indexX},{indexY})");
            rooms[indexX, indexY].direction -= (byte)direction;                             // 元座標の部屋から方向を減算する
        }
    }

    /// <summary>
    /// 部屋生成関数
    /// </summary>
    /// <param name="indexX">生成したい座標x</param>
    /// <param name="indexY">生成したい座標y</param>
    /// <param name="direction">元居た方向</param>
    public void RoomCreate(int indexX, int indexY, LoadDirection direction)
    {
        byte loadDirection = (byte)Random.Range(1, (int)LoadDirection.MAX);     // 方向の乱数値を生成する

        LoadDirection dir = TestRoom.TestReverseDirection(direction);           // 反対の方向を保存する

        if ((loadDirection & (byte)dir) is 0)                                   // 生成した方向にいた方向と逆方向が含まれていなければ
        {
            // Debug.Log($"{loadDirection} & {(byte)dir} is {loadDirection & (byte)dir} : true");
            loadDirection += (byte)dir;                                         // 逆方向を加算する(元居た部屋に対して接続するため)
        }
        else
        {
            // Debug.Log($"{loadDirection} & {(byte)dir} is {loadDirection & (byte)dir} : false");
        }

        rooms[indexX, indexY] = new TestRoom(RoomType.NORMAL, loadDirection);   // 生成座標に通常部屋を生成する

        // Debug.Log($"start({indexX},{indexY}) direction({loadDirection})");

        // 対象方向が生成した方向に含まれているなら方向確認関数を実行する
        if ((loadDirection & (byte)LoadDirection.LEFT) != 0)
        {
            // Debug.Log($"{indexX},{indexY} is LEFT");
            DirectionCheck(indexX, indexY, LoadDirection.LEFT);
        }

        if ((loadDirection & (byte)LoadDirection.RIGHT) != 0)
        {
            // Debug.Log($"{indexX},{indexY} is RIGHT");
            DirectionCheck(indexX, indexY, LoadDirection.RIGHT);
        }

        if ((loadDirection & (byte)LoadDirection.UP) != 0)
        {
            // Debug.Log($"{indexX},{indexY} is UP");
            DirectionCheck(indexX, indexY, LoadDirection.UP);
        }

        if ((loadDirection & (byte)LoadDirection.DOWN) != 0)
        {
            // Debug.Log($"{indexX},{indexY} is DOWN");
            DirectionCheck(indexX, indexY, LoadDirection.DOWN);
        }
    }

    /// <summary>
    /// 特殊な部屋を生成する関数
    /// </summary>
    private void SpecialRoomCreate()
    {
        int randomX, randomY;                                                                           // 乱数値

        // ボス部屋(開始地点から差分3以上)
        while (true)
        {
            randomX = Random.Range(0,rooms.GetLength(0));                                               // 乱数値xを作成
            randomY = Random.Range(0,rooms.GetLength(1));                                               // 乱数値yを作成

            int distance = Mathf.Abs(startX - randomX) + Mathf.Abs(startY - randomY);                   // 開始地点との差分合計値を計算

            if (distance > BOSS_START_DISTANCE && rooms[randomX,randomY].roomType is RoomType.NORMAL)   // 差分値が一定以上かつ生成座標に通常部屋であれば
            {
                rooms[randomX, randomY].roomType = RoomType.MAINBOSS;                                   // メインボス部屋に設定
                break;                                                                                  // ループ終了
            }
        }

        int createCount = 3;

        while (true)
        {
            randomX = Random.Range(0, rooms.GetLength(0));                                               // 乱数値xを作成
            randomY = Random.Range(0, rooms.GetLength(1));                                               // 乱数値yを作成

            if (rooms[randomX, randomY].roomType != RoomType.NORMAL) continue;
            rooms[randomX, randomY].roomType = RoomType.JEIL;
            createCount--;
            if (createCount <= 0) break;
        }

        RoomType createType = RoomType.SHOP;

        while (true)
        {
            randomX = Random.Range(0, rooms.GetLength(0));                                              // 乱数値xを作成
            randomY = Random.Range(0, rooms.GetLength(1));                                              // 乱数値yを作成 

            if (rooms[randomX,randomY].roomType is RoomType.NORMAL)                                     // 生成座標が通常部屋であれば
            {
                rooms[randomX, randomY].roomType = createType;
                createType++;
                if (createType > RoomType.MODULE) break;
            }
        }
    }
}
