﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Talk;
using UniRx;
using Zenject;
using SceneTrans;

public class Lobby : MonoBehaviour
{
    private ITalkStarting talkStarting;
    private DoorController door;
    private EventPoint doorPoint;

    [SerializeField] private TalkSummary startTalk;
    [SerializeField] private GameObject doorObj;

    [Inject] ISceneTrasnable sceneTrasnable = null;
    [SerializeField] SceneInitDataSObj stageSceneSObj = null;

    // Start is called before the first frame update
    void Start()
    {
        if (GameManager.GameProgress is GameProgress.TUTORIAL)
        {
            talkStarting = Locator<ITalkStarting>.GetT();

            //Subject<Unit> sub = new Subject<Unit>();
            //sub.Subscribe(DoorOpen);
            //talkStarting.TalkOpen(startTalk, sub);

            door = doorObj.GetComponent<DoorController>();
            doorPoint = doorObj.GetComponent<EventPoint>();

        }
        else
        {
            //GameManager.tutorialFlg = true;
            door = doorObj.GetComponent<DoorController>();
            doorPoint = doorObj.GetComponent<EventPoint>();
            door.Open();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.GameProgress is GameProgress.TUTORIAL && GameManager.tutorialFlg) DoorOpen();

        if (doorPoint != null && doorPoint.onPlayer && GameManager.tutorialFlg)
        {
            sceneTrasnable.NextScene(stageSceneSObj, "InBattleBGM", "InBattleBGM");
            doorPoint = null;
        }
    }

    private void DoorOpen()
    {
        door.Open();
        GameManager.MakeProgress();
    }
}
