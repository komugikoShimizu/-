﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "RoomList", menuName = "RoomList", order = 1)]
public class RoomList : ScriptableObject
{
    public List<RoomCreateData> normalRoomList = new List<RoomCreateData>();
    public List<RoomCreateData> bossRoomList = new List<RoomCreateData>();
}
