﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;
using CriWare;
using Sound;

namespace Boss
{
    public class BossStageSound : MonoBehaviour
    {
        [Inject] private IBGMPlayable bgmPlayable = null;
        [Inject] private IVolumeSetable volumeSetting = null;

        private const string cueName = "CleanerBGM";
        private const string bossStageSoundName = "CleanerBGM";
    
        void Start()
        {
        
        }

    
        void Update()
        {
        
        }

        /// <summary>
        /// ボス戦のBGMを出す
        /// </summary>
        public void PlayBGMSound()
        {
            bgmPlayable.BGMPlay(cueName, bossStageSoundName);
        }

        /// <summary>
        /// BGMの音量を半減させる
        /// </summary>
        public void BGMSuppress()
        {
            volumeSetting.SetBGMVolumeDucking(BGMVolumeDucking.BGMVolumeSuppress);
        }
    }
}

