﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Enemy;
using System.Linq;
using Manager;
using Zenject;

public class EnemyPool : MonoBehaviour
{
    private List<EnemyCore>[] enemyInstanceData;
    [SerializeField] private EnemyList enemyList;
    [Inject] ISetRegistBoundData setRegistBoundData;

    public void Instance(TestRoom[,] instanceData)
    {
        enemyInstanceData = new List<EnemyCore>[enemyList.enemyList.Count];

        for (int i = 0; i < instanceData.GetLength(0); i++)
        {
            for (int j = 0; j < instanceData.GetLength(1); j++)
            {
                RoomEnemyCheck(instanceData[i,j]);
            }
        }

        for (int i = 0;i < enemyInstanceData.Length;i++)
        {
            for (int j = 0;j < enemyInstanceData[i].Count;j++)
            {
                enemyInstanceData[i][j] = Instantiate(enemyInstanceData[i][j]);
                enemyInstanceData[i][j].instanceId = (i * 100) + j;
                enemyInstanceData[i][j].state = EnemyState.SEARCH;
                enemyInstanceData[i][j].destroyAction += Destroy;
                enemyInstanceData[i][j].gameObject.SetActive(false);
                Debug.Log($"インスタンスを生成 ({enemyInstanceData[i][j].gameObject.name}_{enemyInstanceData[i][j].instanceId})");
            }
        }
    }

    private void RoomEnemyCheck(TestRoom target)
    {
        for (int i = 0; i < enemyList.enemyList.Count; i++)
        {
            if (target is null || target.roomType is RoomType.NONE) continue;
            // Debug.Log(target.roomType);
            Debug.Log($"roop {i}");
            int num = target.roomData.createEnemyID.Count(obj => obj == i);
            if (enemyInstanceData[i] is null) enemyInstanceData[i] = new List<EnemyCore>();

            if (enemyInstanceData[i].Count <= num)
            {
                for (int j = enemyInstanceData[i].Count; j < num  ; j++)
                {
                    // Debug.Log(enemyInstanceData[i].Count);
                    // Debug.Log(num);
                    Debug.Log($"EnemyInstance {i/*target.roomData.createEnemyID[i]*/}");
                    enemyInstanceData[i].Add(enemyList.enemyList[/*target.roomData.createEnemyID[i]*/i]);
                }
            }
        }
    }

    public List<EnemyCore> Create(List<int> idList,List<Vector2> pos)
    {
        List<int> instanceIdList = new List<int>();
        List<EnemyCore> returnData = new List<EnemyCore>();

        for (int i = 0;i < idList.Count;i++)
        {
            for (int j = 0;j < enemyInstanceData[idList[i]].Count;j++)
            {
                Debug.Log($"instance({enemyInstanceData[idList[i]][j].instanceId})");
                if (instanceIdList.Any(obj => obj == enemyInstanceData[idList[i]][j].instanceId)) continue;
                instanceIdList.Add(enemyInstanceData[idList[i]][j].instanceId);
                returnData.Add(enemyInstanceData[idList[i]][j]);
                enemyInstanceData[idList[i]][j].gameObject.SetActive(true);
                enemyInstanceData[idList[i]][j].gameObject.transform.position = pos[i];
                enemyInstanceData[idList[i]][j].state = EnemyState.SEARCH;
                enemyInstanceData[idList[i]][j].id = enemyInstanceData[idList[i]][j].instanceId;
                enemyInstanceData[idList[i]][j].instanceAction?.Invoke();

                setRegistBoundData.SetRegistBoundData().OnNext(enemyInstanceData[idList[i]][j].gameObject);
                break;
            }
        }

        return returnData;
    }

    public void Destroy(int instanceId)
    {
        int index2 = instanceId % 100;
        int index1 = (instanceId - index2) / 100;

        enemyInstanceData[index1][index2].targetObject = null;
        enemyInstanceData[index1][index2].gameObject.transform.position = new Vector3(-200,-200);
        enemyInstanceData[index1][index2].gameObject.SetActive(false);
    }
}
