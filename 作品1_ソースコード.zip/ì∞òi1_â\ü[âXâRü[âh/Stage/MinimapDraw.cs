﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace UI
{
    public class MinimapDraw : MonoBehaviour
    {
        [SerializeField] private StageObject stage;
        [SerializeField] private Sprite createPanelRoom;
        [SerializeField] private Sprite createPnaelload;
        [SerializeField] private List<Image> topImages;
        [SerializeField] private List<Image> centerImages;
        [SerializeField] private List<Image> underImages;
        [SerializeField] private List<Image> verticalLoad1;
        [SerializeField] private List<Image> verticalLoad2;
        [SerializeField] private List<Image> horizontalLoad1;
        [SerializeField] private List<Image> horizontalLoad2;
        [SerializeField] private List<Image> horizontalLoad3;
        [SerializeField] private Sprite start;
        [SerializeField] private Sprite gage;
        [SerializeField] private Sprite sub;
        [SerializeField] private Sprite main;
        [SerializeField] private Sprite shop;
        [SerializeField] private Sprite module;
        [SerializeField] private Sprite player;
        [SerializeField] private Sprite curcor;
        [SerializeField] private Sprite room_b;
        [SerializeField] private Sprite gage_b;
        [SerializeField] private Sprite sub_b;
        [SerializeField] private Sprite main_b;
        [SerializeField] private Sprite shop_b;
        [SerializeField] private Sprite module_b;

        private TestRoom[,] stageData;
        private bool[,] passageArrays;
        private Image[,] verticalLoad = new Image[3,2];
        private Image[,] horizontalLoad = new Image[2, 3];

        private void Start()
        {
            stageData = stage.StageData;
            stage.mapUpdate += Drawing;
            passageArrays = new bool[stageData.GetLength(0), stageData.GetLength(1)];
            for (int i = 0; i < passageArrays.GetLength(0); i++)
            {
                for (int j = 0; j < passageArrays.GetLength(1); j++)
                {
                    passageArrays[i, j] = false;
                }
            }

            verticalLoad[0,0] = verticalLoad1[0];
            verticalLoad[0,1] = verticalLoad1[1];
            verticalLoad[1,0] = verticalLoad1[2];
            verticalLoad[1,1] = verticalLoad2[0];
            verticalLoad[2,0] = verticalLoad2[1];
            verticalLoad[2,1] = verticalLoad2[2];

            horizontalLoad[0, 0] = horizontalLoad1[0];
            horizontalLoad[0, 1] = horizontalLoad1[1];
            horizontalLoad[0, 2] = horizontalLoad2[0];
            horizontalLoad[1, 0] = horizontalLoad2[1];
            horizontalLoad[1, 1] = horizontalLoad3[0];
            horizontalLoad[1, 2] = horizontalLoad3[1];
        }

        private void Drawing(Vector2Int playerPos)
        {
            passageArrays[playerPos.x, playerPos.y] = true;
            stageData = stage.StageData;

            for (int i = 0; i < 3; i++)
            {
                topImages[i].gameObject.SetActive(false);
                centerImages[i].gameObject.SetActive(false);
                underImages[i].gameObject.SetActive(false);
            }

            for (int i = 0;i < horizontalLoad1.Count;i++)
            {
                horizontalLoad1[i].gameObject.SetActive(false);
                horizontalLoad2[i].gameObject.SetActive(false);
                horizontalLoad3[i].gameObject.SetActive(false);
            }

            for (int i = 0;i < verticalLoad1.Count;i++)
            {
                verticalLoad1[i].gameObject.SetActive(false);
                verticalLoad2[i].gameObject.SetActive(false);
            }

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1;j++)
                {
                    Vector2Int pos = playerPos + new Vector2Int(i,j);
                    if (pos.x >= 0 && pos.x < stageData.GetLength(0) && pos.y >= 0 && pos.y < stageData.GetLength(1) && passageArrays[pos.x, pos.y] && stageData[pos.x,pos.y] != null)
                    {
                        if (j is -1)
                        {
                            topImages[i + 1].gameObject.SetActive(true);
                            topImages[i + 1].sprite = DrawImage(pos);
                        }
                        if (j is  0)
                        {
                            centerImages[i + 1].gameObject.SetActive(true);
                            centerImages[i + 1].sprite = DrawImage(pos);
                        }
                        if (j is  1)
                        {
                            underImages[i + 1].gameObject.SetActive(true);
                            underImages[i + 1].sprite = DrawImage(pos);
                        }
                        if (i >= 0 && (stageData[pos.x, pos.y].direction & (byte)LoadDirection.LEFT) != 0 /*&& i + 1 < horizontalLoad.GetLength(0)*/)
                        {
                            if (j is -1)
                            {
                                horizontalLoad1[i].gameObject.SetActive(true);
                                horizontalLoad1[i].sprite = createPanelRoom;
                            }
                            else if (j is  0)
                            {
                                horizontalLoad2[i].gameObject.SetActive(true);
                                horizontalLoad2[i].sprite = createPnaelload;
                            }
                            else if (j is  1)
                            {
                                horizontalLoad3[i].gameObject.SetActive(true);
                                horizontalLoad3[i].sprite = createPnaelload;
                            }
                            if (j is -1)
                            {
                                topImages[i].gameObject.SetActive(true);
                                topImages[i].sprite = DrawImage(pos + Vector2Int.left);
                            }
                            else if (j is 0)
                            {
                                centerImages[i].gameObject.SetActive(true);
                                centerImages[i].sprite = DrawImage(pos + Vector2Int.left);
                            }
                            else if (j is 1)
                            {
                                underImages[i].gameObject.SetActive(true);
                                underImages[i].sprite = DrawImage(pos + Vector2Int.left);
                            }
                        }
                        if (i < 2 && (stageData[pos.x, pos.y].direction & (byte)LoadDirection.RIGHT) != 0 && i + 1 < horizontalLoad.GetLength(0))
                        {
                            if (j is -1)
                            {
                                horizontalLoad1[i + 1].gameObject.SetActive(true);
                                horizontalLoad1[i + 1].sprite = createPnaelload;
                            }
                            else if (j is 0)
                            {
                                horizontalLoad2[i + 1].gameObject.SetActive(true);
                                horizontalLoad2[i + 1].sprite = createPnaelload;
                            }
                            else if (j is 1)
                            {
                                horizontalLoad3[i + 1].gameObject.SetActive(true);
                                horizontalLoad3[i + 1].sprite = createPnaelload;
                            }
                            if (j is -1)
                            {
                                topImages[i + 2].gameObject.SetActive(true);
                                topImages[i + 2].sprite = DrawImage(pos + Vector2Int.right);
                            }
                            else if (j is 0)
                            {
                                centerImages[i + 2].gameObject.SetActive(true);
                                centerImages[i + 2].sprite = DrawImage(pos + Vector2Int.right);
                            }
                            else if (j is 1)
                            {
                                underImages[i + 2].gameObject.SetActive(true); 
                                underImages[i + 2].sprite = DrawImage(pos + Vector2Int.right);
                            }
                        }
                        if (j >= 0 && (stageData[pos.x, pos.y].direction & (byte)LoadDirection.UP) != 0 && j + 1 < verticalLoad.GetLength(1))
                        {
                            if (j is 0)
                            {
                                verticalLoad1[i + 1].gameObject.SetActive(true);
                                verticalLoad1[i + 1].sprite = createPnaelload;
                            }
                            else if (j is 1)
                            {
                                verticalLoad2[i + 1].gameObject.SetActive(true);
                                verticalLoad2[i + 1].sprite = createPnaelload;
                            }
                            if (j is 0)
                            {
                                topImages[i + 1].gameObject.SetActive(true);
                                topImages[i + 1].sprite = DrawImage(pos + Vector2Int.down);
                            }
                            else if (j is 1)
                            {
                                centerImages[i + 1].gameObject.SetActive(true);
                                centerImages[i + 1].sprite = DrawImage(pos + Vector2Int.down);
                            }

                        }
                        if (j < 2 && (stageData[pos.x, pos.y].direction & (byte)LoadDirection.DOWN) != 0/* && j + 2 < verticalLoad.GetLength(1)*/)
                        {
                            if (j is -1)
                            {
                                verticalLoad1[i + 1].gameObject.SetActive(true);
                                verticalLoad1[i + 1].sprite = createPnaelload;
                            }
                            else if (j is 0)
                            {
                                verticalLoad2[i + 1].gameObject.SetActive(true);
                                verticalLoad2[i + 1].sprite = createPnaelload;
                            }
                            if (j is -1)
                            {
                                centerImages[i + 1].gameObject.SetActive(true);
                                centerImages[i + 1].sprite = DrawImage(pos + Vector2Int.up);
                            }
                            else if (j is 0)
                            {
                                underImages[i + 1].gameObject.SetActive(true);
                                underImages[i + 1].sprite = DrawImage(pos + Vector2Int.up);
                            }
                        }
                    }
                }
            }
        }

        private Sprite DrawImage(Vector2Int position)
        {
            switch (stageData[position.x,position.y].roomType)
            {
                case RoomType.START: return start;
                case RoomType.NORMAL:
                    if (passageArrays[position.x, position.y]) return createPanelRoom;
                    else return room_b;
                case RoomType.JEIL:
                    if (passageArrays[position.x, position.y]) return gage;
                    else return gage_b;
                case RoomType.SHOP:
                    if (passageArrays[position.x, position.y]) return shop;
                    else return shop_b;
                case RoomType.SUBBOSS:
                    if (passageArrays[position.x, position.y]) return sub;
                    else return sub_b;
                case RoomType.MODULE:
                    if (passageArrays[position.x, position.y]) return module;
                    else return module_b;
                case RoomType.MAINBOSS:
                    if (passageArrays[position.x, position.y]) return main;
                    else return main_b;
            }

            return null;
        }
    }
}