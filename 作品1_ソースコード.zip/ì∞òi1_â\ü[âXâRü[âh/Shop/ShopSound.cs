﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sound;
using CriWare;
using Zenject;

namespace Shop
{
    public class ShopSound : MonoBehaviour
    {
        [Inject] private ISoundSetable soundSetting = null;

        private const string acbName = "Shop";

        private const string buySoundName = "ShMe_Buy";

        private CriAtomExPlayback buySoundPlayback;
    
        /// <summary>
        /// 購入した時の音
        /// </summary>
        public void PlayBuySound()
        {
            soundSetting.Play(SoundCategory.GameSE, acbName, buySoundName, ref buySoundPlayback);
        }
    }
}

