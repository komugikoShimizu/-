﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Module;
using Player;
using System;
using UniRx;
using DG.Tweening;
using TMPro;

namespace Shop
{
    public class ShopMenu : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI talkText;
        [SerializeField] private TextMeshProUGUI nameText;
        [SerializeField] private TextMeshProUGUI powerText;
        [SerializeField] private Button[] moduleButtons = new Button[4];
        [SerializeField] private Button backButton;
        [SerializeField] private Button moneyButton;
        [SerializeField] private List<String> str;

        [Header("Sound")]
        [SerializeField] ShopSound sound = null;

        public static ShopMenu thisObj;

        private int index = 0;
        private bool shopOpen = false;
        private PlayerCore StatusGetter;
        private ModuleContainer container;
        private List<ModuleStatus> modSta;
        private List<bool> bays = new List<bool>();
        private List<RectTransform> transforms = new List<RectTransform>();
        private List<Vector2> basePosList = new List<Vector2>();
        private IObserver<Unit> closeAction;
        private List<Sequence> sequences = new List<Sequence>();
        private List<Sequence> moveSequences = new List<Sequence>();
        private List<Sequence> returnSequences = new List<Sequence>();

        public void Awake()
        {
            for (int i = 0; i < moduleButtons.Length; i++)
            {
                transforms.Add(moduleButtons[i].GetComponent<RectTransform>());
                basePosList.Add(transforms[i].localPosition);
                sequences.Add(DOTween.Sequence());
            }

            StatusGetter = GameObject.Find("Player").GetComponent<PlayerCore>();
            container = GameObject.Find("Player").GetComponent<ModuleContainer>();

            thisObj = this;
            gameObject.SetActive(false);
        }

        // Update is called once per frame
        void Update()
        {
            if (!shopOpen) return;

            if (Input.GetKeyDown(KeyCode.UpArrow)) IndexChenge(index - 1);
            if (Input.GetKeyDown(KeyCode.DownArrow)) IndexChenge(index + 1);
        }

        public void MenuOpen(List<ModuleStatus> statuses,IObserver<Unit> close)
        {
            if (bays.Count is 0)
            {
                bays.Add(false);
                bays.Add(false);
                bays.Add(false);
                bays.Add(false);
            }

            for (int i = 0;i < statuses.Count;i++)
            {
                moduleButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = statuses[i].nameGet;
            }

            GameManager.GameState = GameState.SHOP;
            closeAction = close;
            modSta = statuses;
            shopOpen = true;
            if (statuses.Count > 3) moduleButtons[3].GetComponent<Image>().sprite = moduleButtons[0].GetComponent<Image>().sprite;
            TextUpdate();
        }

        private void TextUpdate()
        {
            string talk = str[UnityEngine.Random.Range(0, str.Count)];
            nameText.text = modSta[index].nameGet;
            powerText.text = modSta[index].statementGet;
            talkText.text = talk;
        }

        private void TextUpdate_comp()
        {
            nameText.text = modSta[index].nameGet;
            powerText.text = modSta[index].statementGet;
            talkText.text = "カンバイオンレイ!";
        }

        private void IndexChenge(int newIndex)
        {
            int old = index;
            index = Mathf.Clamp(newIndex, 0, modSta.Count - 1);
            if (bays[index]) TextUpdate_comp();
            else if (old != index) TextUpdate();

            for (int i = 0;i < moduleButtons.Length;i++)
            {
                sequences[i] = DOTween.Sequence();
                if (index == i) sequences[i].Append(transforms[i].DOAnchorPosX(basePosList[i].x - 70, 0.2f).SetEase(Ease.Unset));
                else sequences[i].Append(transforms[i].DOAnchorPosX(basePosList[i].x,0.2f).SetEase(Ease.Unset));
            }
        }

        public void Mod1()
        {
            IndexChenge(0);
        }

        public void Mod2()
        {
            IndexChenge(1);
        }

        public void Mod3()
        {
            IndexChenge(2);
        }

        public void Mod4()
        {
            IndexChenge(3);
        }

        public void Back()
        {
            closeAction.OnNext(default);
            shopOpen = false;
            GameManager.GameState = GameState.GAME;
        }

        public void Bay()
        {
            if (StatusGetter.scrap_ >= 10)
            {
                //StatusGetter.scrap_ -= 10;
                StatusGetter.SetScrapValue(-10);
                container.AddExe(modSta[index]);
                bays[index] = true;
                moduleButtons[index].gameObject.SetActive(false);
                talkText.text = "ガンバリオンレイ!";
                sound.PlayBuySound();
            }
            else
            {
                talkText.text = "オカネガタリナイヨウデスネ...";
            }
        }
    }
}