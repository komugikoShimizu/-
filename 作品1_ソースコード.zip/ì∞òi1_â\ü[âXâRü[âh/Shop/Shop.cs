﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Player;
using Module;
using Talk;
using Inputs;
using System;
using UniRx;
using npc;
using UI.Shop;

namespace Shop
{
    public class Shop : npcController
    {
        private InputManager input;
        [SerializeField] private ModuleList moduleList;
        [SerializeField] private ITalkStarting talkManager;
        [SerializeField] private ShopMenu shopMenu;

        private ShopUIModel shopUI;
        private bool onTalk = false;

        private void Comp(Unit unit)
        {
            Subject<Unit> close = new Subject<Unit>();
            close.Subscribe(Exit);
            shopUI.Actvate(moduleList.statuses,close);
        }

        private void Exit(Unit unit)
        {
            onTalk = false;
        }

        protected override void Startup()
        {
            base.Startup();
            talkManager = Locator<ITalkStarting>.GetT();
            input = Locator<InputManager>.GetT();
            shopUI = Locator<ShopUIModel>.GetT();
        }

        protected override void Talk()
        {
            if (onPlayer && !onTalk && input.InteractInput())
            {
                if (GameManager.shopTalkFlg)
                {
                    Comp(default);
                    onTalk = true;
                }
                else
                {
                    Subject<Unit> subject = new Subject<Unit>();
                    subject.Subscribe(Comp);
                    talkManager.TalkOpen(talkSummary[0], subject);
                    onTalk = true;
                    GameManager.shopTalkFlg = true;
                }
            }
        }

        protected override void EnterAction(Collider2D collsion)
        {
            if (collsion.gameObject.layer is 3 && !onPlayer)
            {
                onPlayer = true;
                displayInput.DisplayImage();
            }
        }

        protected override void ExitAction(Collider2D collision)
        {
            base.ExitAction(collision);
        }
    }
}