﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UniRx;
using Zenject;
using Inputs;
using Sound;

namespace Talk
{
    public class TalkManager : MonoBehaviour,ITalkStarting
    {
        [Inject] private InputManager input;
        [Inject] private IVolumeSetable volumeSetting = null;
        [SerializeField,Tooltip("文字送りの間隔")] private float stopCount = 0.2f;
        [SerializeField,Tooltip("本文表示テキスト")] private Text text;
        [SerializeField,Tooltip("名前表示テキスト")] private Text nameText;
        [SerializeField,Tooltip("名前表示パネル")] private Image namePnael;
        [SerializeField,Tooltip("本文表示パネル")] private Image talkPanel;
        [SerializeField,Tooltip("左側キャラ表示")] private Image imageLeft;
        [SerializeField,Tooltip("右側キャラ表示")] private Image imageRight;
        [SerializeField,Tooltip("中央キャラ表示")] private Image imageCenter;
        [SerializeField,Tooltip("暗転背景")] private Image backGround;
        [SerializeField,Tooltip("文字送りアイコン")] private Image icon;
        [SerializeField,Tooltip("サウンド")] private TalkSound talkSound;

        private int index = 0;                                  // 会話状況
        private bool textDrawing = false;                       // 会話表示中かどうか
        private TalkSummary talkSummary;                        // 会話内容
        private Coroutine textDraw = null;                      // 会話表示コルーチン
        private IObserver<Unit> observer;                       // 終了時イベント

        public void Awake()
        {
            Locator<ITalkStarting>.Bind(this);  // ロケータにインタフェースを公開
        }

        // Update is called once per frame
        void Update()
        {
            if (talkSummary is null) return;    // 会話がないときは処理しない

            if (input.UISubmit() || Input.GetMouseButtonDown(0))    // 入力されたとき
            {
                if (textDrawing)    // 会話送り中なら 
                {
                    text.text = talkSummary.texts[index]; // 原文を表示
                    StopCoroutine(textDraw);              // コルーチンを停止
                    textDrawing = false;                  // 会話送りフラグをfalseへ
                    index++;                              // 次回会話へ
                    return;
                }

                if (index >= talkSummary.texts.Count)     // 表示する会話がなくなったら 
                {
                    volumeSetting.SetBGMVolumeDucking(BGMVolumeDucking.BGMVolumeFull); // 音量調整
                    backGround.gameObject.SetActive(false);                            // 背景非表示
                    imageLeft.gameObject.SetActive(false);                             // キャラ画像透明化
                    imageRight.gameObject.SetActive(false);                            // キャラ画像透明化
                    // imageCenter.gameObject.SetActive(false);
                    text.text = default;                                               // テキスト非表示
                    nameText.text = default;                                           // テキスト非表示
                    talkSummary = null;                                                // 表示会話を消す
                    index = 0;                                                         // 会話進捗を初期化
                    talkPanel.gameObject.SetActive(false);                             // 背景画像を初期化
                    namePnael.gameObject.SetActive(false);                             // 背景画像を初期化
                    icon.gameObject.SetActive(false);                                  // アイコン非表示
                    GameManager.GameState = GameState.GAME;                            // ゲームステートをgame状態へ

                    if (observer != null)                                              // 終了イベントが存在するなら
                    {
                        observer.OnNext(default);                                      // 終了イベント実行
                        observer = null;                                               // 終了イベント初期化
                    }
                }
                else
                {
                    textDraw = StartCoroutine(TextDraw(talkSummary.texts[index]));                  // 文字送りコルーチン実行
                    nameText.text = talkSummary.talkMenberName[talkSummary.talkingIndex[index]];    // 名前表示
                    if (talkSummary.talkMenberSides[talkSummary.talkingIndex[index]] is TalkSide.LEFT) imageLeft.sprite = talkSummary.talkMenber[talkSummary.talkingIndex[index]];      // 画像更新
                    if (talkSummary.talkMenberSides[talkSummary.talkingIndex[index]] is TalkSide.RIGHT) imageRight.sprite = talkSummary.talkMenber[talkSummary.talkingIndex[index]];    // 画像更新
                    ColorReset();                                                                   // 色変更
                }
            }
        }

        public void TalkOpen(TalkSummary talk,IObserver<Unit> compleate = null)
        {
            if (talkSummary != null) return;

            // BGM音量を現在の半分にする
            volumeSetting.SetBGMVolumeDucking(BGMVolumeDucking.BGMVolumeSuppress);

            talkSummary = talk;                                                                 // 会話情報設定

            observer ??= compleate;                                                             // 終了イベント設定
            GameManager.GameState = GameState.TALK;                                             // ゲームステートをtalkへ

            talkPanel.gameObject.SetActive(true);                                               // 背景画像を設定
            namePnael.gameObject.SetActive(true);                                               // 背景画像を設定
            icon.gameObject.SetActive(true);                                                    // アイコン表示
            backGround.gameObject.SetActive(true);                                              // 背景画像を初期化
            textDraw = StartCoroutine(TextDraw(talkSummary.texts[index]));                      // 文字送りコルーチン実行
            nameText.text = talkSummary.talkMenberName[talkSummary.talkingIndex[index]];        // 名前表示
            for (int i = 0; i < talkSummary.talkingIndex.Count; i++)                            // 会話数分実行
            {
                if (talkSummary.talkMenberSides[talkSummary.talkingIndex[i]] is TalkSide.LEFT)  // 左側にキャラ情報があれば設定
                {
                    imageLeft.gameObject.SetActive(true);                                       
                    imageLeft.sprite = talkSummary.talkMenber[talkSummary.talkingIndex[i]];     
                    imageLeft.SetNativeSize();                                                  
                }
                if (talkSummary.talkMenberSides[talkSummary.talkingIndex[i]] is TalkSide.RIGHT) // 右側にキャラ情報があれば設定
                {   
                    imageRight.gameObject.SetActive(true);                                      
                    imageRight.sprite = talkSummary.talkMenber[talkSummary.talkingIndex[i]];    
                    imageRight.SetNativeSize();                                                 
                }
            }

            ColorReset();                                                                       // 色を変更
        }

        /// <summary>
        /// 文字送りコルーチン
        /// </summary>
        /// <param name="textContant"></param>
        /// <returns></returns>
        private IEnumerator TextDraw(string textContant)
        {
            bool colorCode = false; // カラーコードを検知したかどうか

            textDrawing = true;     // 文字送り実行中に設定

            for (int i = 0;i <= textContant.Length;i++)                     // 文字数分回す
            {
                string text_ = textContant.Substring(0, i);                 // 回った回数分文字を設定
                if (colorCode) text_ += "</color>";                         // カラーコード検知済みなら</color>をつける

                if (i < textContant.Length)                                 // 次もfor分を実行できるなら
                {
                    char c = textContant[i];                                // 今回の文字を取得

                    if (c is '<')                                           // カラーコードの最初を検知したら
                    {
                        while (true)
                        {
                            i++;                                            // 回った回数を強制追加
                            char c_ = textContant[i];                       // 追加後の文字を取得
                            if (c_ is '>')                                  // カラーコード終了を検知したら
                            {
                                text.text = textContant.Substring(0, i);    // テキストを出力
                                break;
                            }
                        }
                        colorCode = colorCode ? false : true;               // カラーコード検知フラグを反転
                    }
                }

                text.text = text_;                                          // テキスト出力

                // <!>臨時<!> 名前で会話次流れる効果音を変更
                if (talkSummary.talkMenberName[talkSummary.talkingIndex[index]] is "エンドー博士") talkSound.PlayTalkEndoSound();
                else if (talkSummary.talkMenberName[talkSummary.talkingIndex[index]] is "クラーク") talkSound.PlayTalkClerkSound();
                else talkSound.PlayTalkMaidSound();

                yield return new WaitForSeconds(stopCount);                 // 停止時間分停止
            }

            index++;                                                        // 会話進捗加算
            textDrawing = false;                                            // 文字送り実行フラグをfalseに
        }

        /// <summary>
        /// 会話者の彩度等を変更する
        /// </summary>
        private void ColorReset()
        {
            if (talkSummary.talkMenberSides[talkSummary.talkingIndex[index]] is TalkSide.LEFT)  // 現在の会話者が左側なら
            {
                imageLeft.color = Color.white;                                                  // 左側を表示
                imageRight.color = new Color(0.2f,0.2f,0.2f,1f);                                // 右側の彩度を落とす
                // imageCenter.color = Color.black;
            }

            // 以下同じような流れ
            if (talkSummary.talkMenberSides[talkSummary.talkingIndex[index]] is TalkSide.RIGHT)
            {
                imageLeft.color = new Color(0.2f, 0.2f, 0.2f, 1f);
                imageRight.color = Color.white;
                // imageCenter.color = Color.black;
            }
            if (talkSummary.talkMenberSides[talkSummary.talkingIndex[index]] is TalkSide.CENTER)
            {
                imageLeft.color = new Color(0.2f, 0.2f, 0.2f, 1f);
                imageRight.color = new Color(0.2f, 0.2f, 0.2f, 1f);
                // imageCenter.color = Color.white;
            }
        }
    }
}