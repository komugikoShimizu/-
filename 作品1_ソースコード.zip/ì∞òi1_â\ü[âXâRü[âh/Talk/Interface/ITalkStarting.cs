﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Talk;
using System;
using UniRx;

namespace Talk
{
    public interface ITalkStarting
    {
        public void TalkOpen(TalkSummary talk, IObserver<Unit> compleate = null);
    }
}