﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Talk
{
    public class TalkSummary : ScriptableObject
    {
        [TextArea] public List<string> texts;
        public List<int> talkingIndex;
        public List<Sprite> talkMenber;
        public List<string> talkMenberName;
        public List<TalkSide> talkMenberSides;
    }
}