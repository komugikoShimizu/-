﻿#if UNITY_EDITOR

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Talk
{
    public class TalkCreater : EditorWindow
    {
        [MenuItem("Window/TalkCreate")]
        static void WindowOpen()
        {
            GetWindow<TalkCreater>("TalkCreate");            // 表示処理
        }

        private TalkSummary talkSummary;
        private string assetName = default;
        private Vector2 scrollPosition = Vector2.zero;

        private List<Sprite> talkMenber = new List<Sprite>();
        private List<string> talkMenberName = new List<string>();
        private List<TalkSide> talkMenberSides = new List<TalkSide>();
        private List<string> talkTexts = new List<string>();
        private List<int> talkNumber = new List<int>();

        private int talkMenberNumber = 1;
        private int talkCount = 1;

        private bool talkMenberDraw = true;
        private List<bool> talkTextDraws = new List<bool>();

        private void OnGUI()
        {
            EditorGUILayout.LabelField("会話作成ツール");

            EditorGUILayout.LabelField("会話名称(可能であれば英数)");
            assetName = EditorGUILayout.TextField(assetName);

            GUIStyle _style = new GUIStyle();

            Rect _rect = EditorGUILayout.BeginVertical(GUI.skin.box);
            {
                if (talkMenberDraw)
                {
                    if (GUILayout.Button("登場人物設定欄非表示")) talkMenberDraw = false;

                    EditorGUILayout.LabelField("会話登場人物数(最大5名)");
                    talkMenberNumber = EditorGUILayout.IntField(talkMenberNumber);
                    talkMenberNumber = Mathf.Clamp(talkMenberNumber, 1, 5);

                    if (talkMenberNumber > talkMenber.Count)
                    {
                        for (int i = talkMenber.Count - 1; i < talkMenberNumber; i++)
                        {
                            talkMenber.Add(null);
                            talkMenberName.Add("none Name");
                            talkMenberSides.Add(TalkSide.LEFT);
                        }
                    }

                    for (int i = 0; i < talkMenberNumber; i++)
                    {
                        EditorGUILayout.LabelField("------------------------");
                        EditorGUILayout.LabelField($"会話登場者({i})設定項目");
                        EditorGUILayout.LabelField("画像");
                        talkMenber[i] = EditorGUILayout.ObjectField(talkMenber[i], typeof(Sprite), true) as Sprite;
                        EditorGUILayout.LabelField("名前");
                        talkMenberName[i] = EditorGUILayout.TextField(talkMenberName[i]);
                        EditorGUILayout.LabelField("登場位置");
                        talkMenberSides[i] = (TalkSide)EditorGUILayout.EnumPopup(talkMenberSides[i]);
                    }
                }
                else if (GUILayout.Button("登場人物設定欄表示")) talkMenberDraw = true;

            }
            EditorGUILayout.EndVertical();

            _rect = EditorGUILayout.BeginVertical(GUI.skin.box);
            {
                scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
                {
                    EditorGUILayout.LabelField("会話内容数(最大50個)");

                    talkCount = EditorGUILayout.IntField(talkCount);
                    talkCount = Mathf.Clamp(talkCount, 1, 50);

                    if (talkCount > talkTexts.Count)
                    {
                        for (int i = talkTexts.Count - 1; i < talkCount; i++)
                        {
                            talkTextDraws.Add(false);
                            talkTexts.Add(default);
                            talkNumber.Add(0);
                        }
                    }

                    for (int i = 0; i < talkCount; i++)
                    {
                        EditorGUILayout.LabelField("------------------------");
                        if (talkTextDraws[i])
                        {
                            if (GUILayout.Button($"会話({i})設定欄非表示")) talkTextDraws[i] = false;
                            EditorGUILayout.LabelField($"会話内容");
                            talkTexts[i] = EditorGUILayout.TextArea(talkTexts[i]);
                            EditorGUILayout.LabelField("会話者");
                            talkNumber[i] = EditorGUILayout.Popup(talkNumber[i], talkMenberName.ToArray());
                        }
                        else if (GUILayout.Button($"会話({i})設定欄表示")) talkTextDraws[i] = true;
                    }
                }
                EditorGUILayout.EndScrollView();
            }
            EditorGUILayout.EndVertical();

            if (GUILayout.Button("セーブ"))
            {
                Save();
            }
        }

        private void Save()
        {
            talkSummary = ScriptableObject.CreateInstance<TalkSummary>();

            talkSummary.name = assetName;

            talkSummary.talkingIndex = talkNumber;
            talkSummary.talkMenber = talkMenber;
            talkSummary.talkMenberName = talkMenberName;
            talkSummary.talkMenberSides = talkMenberSides;
            talkSummary.texts = talkTexts;

            string savePath = $"Assets/TalkDatas/{assetName}.asset";

            AssetDatabase.CreateAsset(talkSummary, savePath);
            EditorUtility.SetDirty(talkSummary);
            AssetDatabase.SaveAssets();
        }
    }
}

#endif