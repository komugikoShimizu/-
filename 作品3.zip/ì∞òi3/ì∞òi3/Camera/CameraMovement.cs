﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

namespace N2.Camera
{
    public class CameraMovement : MonoBehaviour
    {
        [SerializeField, Tooltip("シネマシーンのVC")] private CinemachineVirtualCamera mainVirtualCamera;
        [SerializeField, Tooltip("参照する注視点")] private ViewPoint viewPoint;
        [SerializeField, Tooltip("移動を行うかどうか")] private bool removable = true;

        private CinemachineTrackedDolly virtualCameraTrackedDolly;

        private void Start()
        {
            if (mainVirtualCamera || !removable)
            {
                // VCamのパス移動を行うためのクラスを取得
                virtualCameraTrackedDolly = mainVirtualCamera.GetCinemachineComponent<CinemachineTrackedDolly>(); 
            }
        }

        private void LateUpdate()
        {
            if (mainVirtualCamera is null || !removable) return;

            // 座標割合を注視点から取得し、代入する
            virtualCameraTrackedDolly.m_PathPosition = viewPoint.transferRatio;
        }

        public void Activate()
        {
            mainVirtualCamera.Priority = 10;
        }

        public void Deactivate()
        {
            mainVirtualCamera.Priority = 0;
        }

        public float transferRatio => viewPoint.transferRatio;
    }
}
