﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace N2.Camera
{
    public class CameraContoller : MonoBehaviour
    {
        [SerializeField] private CameraMovement[] useCameraArray;

        private int useCameraIndex = 0;

        // Update is called once per frame
        void Update()
        {
            if (useCameraArray[useCameraIndex].transferRatio >= 1f)
            {
                useCameraArray[useCameraIndex].Deactivate();
                useCameraIndex = Mathf.Clamp(useCameraIndex + 1,0,useCameraArray.Length - 1);
                useCameraArray[useCameraIndex].Activate();
            }
            if (useCameraArray[useCameraIndex].transferRatio <= 0f)
            {
                useCameraArray[useCameraIndex].Deactivate();
                useCameraIndex = Mathf.Clamp(useCameraIndex - 1, 0, useCameraArray.Length - 1);
                useCameraArray[useCameraIndex].Activate();
            }

        }
    }
}
