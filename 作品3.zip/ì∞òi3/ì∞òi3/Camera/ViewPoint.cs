﻿using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Splines;

namespace N2.Camera
{

    public class ViewPoint : MonoBehaviour
    {
        [SerializeField,Tooltip("注視対象")] private GameObject targetObject;
        [SerializeField,Tooltip("使用するスプライン")] private SplineContainer spline;

        public float transferRatio { get; private set; }

        // Update is called once per frame
        void Update()
        {
            // 設定すべき項目が未設定の場合早期リターンする
            if (targetObject is null) return; 
            if (spline is null) return;

            // ワールド空間のスプライン情報
            using NativeSpline nativeSpline = new NativeSpline(
                spline.Spline,
                spline.transform.localToWorldMatrix
            );

            float3 nearestPosition = new float3();
            float nearestRatio = 0;

            // 最寄りのスプライン座標を取得できる関数(out で座標と割合を取得可能)
            SplineUtility.GetNearestPoint(
                nativeSpline,
                targetObject.transform.position,
                out nearestPosition,
                out nearestRatio);

            // 現在座標を最寄りのスプライン上座標に置き換える
            transform.position = nearestPosition;

            // 移動割合をプロパティに代入
            transferRatio = nearestRatio;
        }
    }
}
